# Cross Trade Execution Service

This is a standalone application that handles trade execution. It
performs the following high-level tasks:

1. Listens to trade execution requests via DynamoDB.
2. Ensures that trades are within firm credit limits.
3. Executes the trade via [msglib].

## Message bus

Trade execution requests come from Orderbook through [msglib].

### DynamoDB

A trade is executed via the Cross Trade frontend. When executed, the
trade record is updated in the Cross Trade trades table. The Cross
Trade Execution Service listens to changes in Message bus,
via a [msglib] adapter, and processes the relevant trades.

[DynamoDB]: http://aws.amazon.com/documentation/dynamodb/

## Downstream systems

The following are downstream systems that Cross Trade utilises to
perform certain tasks.

### CRS

In order to execute trades the firm must have sufficient credit.
The CRS system keeps a count of the remaining credit for each
firm on each trading product.

Communication to CRS is established via TCP message bus. The
following hosts are available for credit checks:

- UAT: `uk0wgfxapp01p.uk.icap.com`
- Prod: `uk0wgfxapp02p.uk.icap.com`

**Message bus connectivity**: connection to the message bus is
established via
[`com.icap.fusion.common.messages/fusion-java-messages`][msglib]
library.

In order to ensure the TCP connection to the message bus remains 
active, the application listens to `HeartBeat` messages. Heart 
beats are log regularly and if the application stops receiving 
them, a `MsgLibTCP` instance will be initialised.

**Heart beat monitoring**: The interval for logging and monitoring
heart beat messages is configuratble:

- `crs.heartBeatCheckIntervalSecs`: the application will attempt
  to establish a new connection to the message bus if it does not
  receive a heart beat message for the defined length of time.
  Default is 20 seconds.

- `crs.heartBeatLogIntervalSecs`: the application will log heart
  beat messages once per defined length of time. The logging is
  set at INFO level. Default is 120 seconds.

[msglib]: https://github.icaptools.com/fcommon-client/fusion-message-libraries/tree/master/fusion-java-messages

### GTN

Trades are executed by the RIMS system. In order to book trades
on RIMS, Cross Trade leverages the GTN system which requires that
trades are written to a file and copied into a Samba/CIFS
network drive. A GTN process will take the file and push the
trades onto a message bus for RIMS to consume.

CIFS targets:

- QA: `//gb01uetcgbd01q/GTN-ENVOY`
- Shadow: `//gb01uetcgbd01s/GTN-ENVOY`
- Prod: `//gb00uetcgbd01p/GTN-ENVOY`

The CIFS targets must be mounted in the Linux host in which
this application runs. When this application starts up, it will
verify that it can write to the mounted target. If verification
succeeds there will be a file left in the target path called
`verified.txt`.

Trades are written to files with the following filename pattern:

`envoy_trades_out_{uuid}.csv`

The mount path to which the files are written are configurable
via the following property:

`gtn.targetPath`

Trades files are staged in the JVM's default temporary working
directory before they are copied to the GTN mount path. In case
of IO problems writing to the mount path, it is therefore
possible to view staged trades in the temporary working
directory, usually `/tmp`.

### Swiftt Reference Data

This application requires data on Firms and Traders. It ustilises
the [swiftt-reference-data-standalone-client][refdata] library to
access reference data on Firms and Traders.

[refdata]: https://github.icaptools.com/fcore-services/swiftt-reference-data-standalone

## Features

The following are application features

### Adjusted Price

The brokerage is applied to a trade as follows:

1. The broker rate is retrieved from Trader reference data
2. Since the trader sits on both sides of the trade (in Cross Trade),
   the broker rate is halved and applied on each side.
3. One half of the broker rate is added to the BUY side, and the
   other half is subtracted from the SELL side.

Here's an example:
```
>>> price = 105.26
>>> broker_rate = 0.02
>>> print "BUY price: %s" % (price + (broker_rate / 2))
>>> print "SELL side price: %s" % (price - (broker_rate / 2))
BUY price: 105.27
SELL price: 105.25
```

### Credit Check

In order for a trade to be executed the firm must have sufficient
credit. Sufficient credit is determined as follows:

1. Since all instruments in Cross Trade are fixed income securities,
   the notional is derived by total volume divided by 100 (par
   value).
2. The notional values are added up.
3. The total must be less than the remaining credit.

In code:
```
limit = crs.get_limit(group_code)
total = trades
          .map(trade -> trade.adjusted_price * trade.size / 100)
          .reduce(total, notional -> total + notional)
if (total > limit.remainder)
  print "Insufficient credit"
```

Known issues:

- Since there is a delay between execution in RIMS and credit
  limits updating in CRS, it is possible for a firm to exceed its
  limit. The long term solution is to keep a live count in
  memory. The best solution is for credit limits to be updated
  in real time downstream (by CRS).

### Batch Execution

Trades are executed in batches. When a trade is received from
upstream it will be placed in a queue. Meanwhile a thread is
started which takes from the queue, waiting for all trades in the
batch to arrive before executing the trades.

If there are any errors processing a trade, all trades in the
batch will be rejected, and may be attempted again at a later
time (via the Cross Trade frontend). If a trade is dropped due to
upstream failure, the awaiting batch will timeout and all trades
in the batch will be rejected, and may be attempted again at a
later time. The batch timeout can be configured via application
property, `execution.batchTimeout`, set as seconds.

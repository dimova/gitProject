package com.icap.truequote.crosstrade.execution;

public class TradeExecutionException extends RuntimeException {
    public TradeExecutionException(String reason) {
        super(reason);
    }

    public TradeExecutionException(String reason, Throwable cause) {
        super(reason, cause);
    }
}

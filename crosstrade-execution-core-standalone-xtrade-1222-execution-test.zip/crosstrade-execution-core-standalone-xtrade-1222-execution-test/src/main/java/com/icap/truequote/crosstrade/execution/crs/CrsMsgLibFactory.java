package com.icap.truequote.crosstrade.execution.crs;

import com.icap.altex.MsgLib.ConnectionListener;
import com.icap.altex.MsgLib.MsgLib;
import com.icap.altex.MsgLib.MsgLibTCP;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CrsMsgLibFactory {

    private static Logger LOG = LoggerFactory.getLogger(CrsMsgLibFactory.class);

    private final String hostname;
    private final int port;
    private final String username;
    private final String password;

    public CrsMsgLibFactory(String hostname, int port, String username, String password) {
        this.hostname = hostname;
        this.port = port;
        this.username = username;
        this.password = password;
    }

    public MsgLib getMsgLib(ConnectionListener listener) {
        MsgLibTCP msglib = new MsgLibTCP(hostname, port, username, password);
        try {
            LOG.info("Connecting to CRS message bus...", msglib);
            msglib.addConnectionListener(listener);
            msglib.connect();
        } catch (Exception e) {
            throw new CRSException("Could not connect to message bus.", e);
        }
        return msglib;
    }
}

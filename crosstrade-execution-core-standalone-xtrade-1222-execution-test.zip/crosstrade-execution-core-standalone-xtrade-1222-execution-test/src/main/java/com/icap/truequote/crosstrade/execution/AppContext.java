package com.icap.truequote.crosstrade.execution;

import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.icap.altex.MsgLib.enums.MsgType;
import com.icap.envoy.crosstrade.auditing.EnvoyAuditComponents;
import com.icap.envoy.crosstrade.auditing.EnvoyAuditLog;
import com.icap.envoy.crosstrade.dao.PositionDao;
import com.icap.envoy.crosstrade.dao.TradeDao;
import com.icap.envoy.crosstrade.referencedata.api.Environment;
import com.icap.fusion.altex.*;
import com.icap.fusion.configuration.RabbitMqConfiguration;
import com.icap.truequote.crosstrade.execution.crs.CRSContext;
import com.icap.truequote.crosstrade.execution.crs.CRSService;
import com.icap.truequote.crosstrade.execution.crs.fxpair.FxPairService;
import com.icap.truequote.crosstrade.execution.gtn.GTNService;
import com.icap.truequote.crosstrade.execution.gtn.GTNTradeAppender;
import com.icap.truequote.crosstrade.handler.firm.FirmUpdateCacheHandler;
import com.icap.truequote.crosstrade.handler.instrument.InstrumentUpdateCacheHandler;
import com.icap.truequote.crosstrade.handler.trader.TraderUpdateCacheHandler;
import com.icap.truequote.crosstrade.service.CacheService;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.web.client.RestTemplate;

import javax.sql.DataSource;
import java.io.*;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Clock;

import static java.lang.String.format;

@Import({ AwsContext.class, PropertiesContext.class, CRSContext.class})
@Configuration
public class AppContext {

    private static final Logger LOG = LoggerFactory.getLogger(AppContext.class);

    private static final String TEMP_DIR = System.getProperty("java.io.tmpdir");

    private DateTimeFormatter df = ISODateTimeFormat.dateTimeNoMillis();

    @Bean
    public AWSCredentialsProvider awsCredentials() {
        return new DefaultAWSCredentialsProviderChain();
    }

    @Bean
    public RabbitMqConfiguration rabbitMqConfiguration(@Value("${rmq.host}") String host,
                                                       @Value("${rmq.port}") Integer port,
                                                       @Value("${rmq.vhost}") String virtualHost,
                                                       @Value("${rmq.user}") String username,
                                                       @Value("${rmq.password}") String password,
                                                       @Value("${rmq.connectionTimeout}") Integer connectionTimeout,
                                                       @Value("${rmq.rpcReplyTimeout}") Integer rpcReplyTimeout,
                                                       @Value("${rmq.requestedHeartBeat}") Integer requestedHeartBeat,
                                                       @Value("${rmq.channelCacheSize}") Integer channelCacheSize,
                                                       @Value("${rmq.enablePublisherConfirms}") boolean enablePublisherConfirms) {
        return new RabbitMqConfiguration(
                host,
                port,
                virtualHost,
                username,
                password,
                connectionTimeout,
                rpcReplyTimeout,
                requestedHeartBeat,
                channelCacheSize,
                enablePublisherConfirms);
    }

    @Bean
    public MsgLibConnectionListenerFactory connectionListenerFactory() {
        return new MsgLibConnectionListenerFactory();
    }

    @Bean
    public MsgLibFactory msgLibFactory(RabbitMqConfiguration config,
                                       @Value("${message.lib.componentId}") String componentId,
                                       @Value("${message.lib.exchange}") String exchange,
                                       @Value("${message.lib.topicPrefix}") String topicPrefix) {
        return new MsgLibFactory(config, componentId, exchange, topicPrefix);
    }

    @Bean
    public MsgLibConnectionConfig msgLibConnectionConfig(
            MsgLibFactory msgLibFactory,
            MsgLibConnectionListenerFactory connectionListenerFactory,
            @Value("${message.lib.heartBeatCheckIntervalSecs}") int heartBeatCheckInterval,
            @Value("${message.lib.heartBeatLogIntervalSecs}") int heartBeatLogInterval,
            @Value("${message.lib.maxSendAttempts}") int maxSendAttempts,
            @Value("${message.lib.remoteHeartBeatTopic}") String remoteHeartBeatTopic,
            @Value("${message.lib.heartBeatTopic}") String heartBeatTopic) {
        return new MsgLibConnectionConfig(msgLibFactory, connectionListenerFactory, heartBeatCheckInterval, heartBeatLogInterval,
                maxSendAttempts, remoteHeartBeatTopic, heartBeatTopic, true);
    }

    @Bean
    public MsgLibConnection msgLibConnection(MsgLibConnectionConfig msgLibConnectionConfig) {
        MsgLibConnection msgLibConnection = new DefaultMsgLibConnection(msgLibConnectionConfig);
        msgLibConnection.connect();
        return msgLibConnection;
    }

    @Bean
    public TradeExecutionHandler tradeExecutionHandler(
            MsgLibConnection msgLibConnection,
            CRSService crs,
            GTNService gtn,
            TradeDao tradeDao,
            PositionDao positionDao,
            CacheService cacheService,
            FxPairService fxPairService,
            @Value("${execution.batchTimeout}") int batchTimeout,
            @Value("${altex.user.group.names}") String groupNames,
            EnvoyAuditLog envoyAuditLog) {

        TradeExecutionHandler handler = new TradeExecutionHandler(crs, gtn, tradeDao, positionDao, cacheService,
                fxPairService, batchTimeout, groupNames, msgLibConnection, envoyAuditLog);

        msgLibConnection.addMessageListener("*", MsgType.CrosstradeTradeExecutions, handler);

        return handler;
    }

    @Bean
    public GTNService gtnService(
            GTNTradeAppender GTNTradeAppender,
            Clock clock,
            @Value("${gtn.targetPath:}") String targetPath,
            @Qualifier("instanceName") String instanceName) throws IOException {

        /* TODO: verify the target path regularly (not just on startup) */
        verifyTargetPath(targetPath, instanceName);
        return new GTNService(GTNTradeAppender, targetPath, clock);
    }

    private void verifyTargetPath(String targetPath, String instanceName) throws IOException {
        if (isBlank(targetPath)) {
            LOG.info("gtn.targetPath property not specified. Running in dev mode?");
            return;
        }
        String tempFile = format("%s%sverified.txt", TEMP_DIR, File.separator);

        Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(tempFile), "utf-8"));
        writer.write(format("This directory was verified by Envoy Trade Booking Service: host=%s, time=%s\n",
                instanceName, df.print(new DateTime())));
        writer.close();

        Path source = new File(tempFile).toPath();
        Path target = new File(targetPath).toPath().resolve(source.getFileName());
        Files.copy(source, target, StandardCopyOption.REPLACE_EXISTING);
        LOG.info(format("GTN target path verified: %s", target.toString()));
    }

    @Bean
    public GTNTradeAppender tradeRecordMarshaller(CacheService cacheService, @Value("${gtn.marketId:}") String marketId) {
        return new GTNTradeAppender(cacheService, marketId);
    }

    @Bean
    public TradeDao tradeDao(DynamoDBMapper dynamoDBMapper, Clock clock) {
        return new TradeDao(dynamoDBMapper, clock);
    }

    @Bean
    public PositionDao positionDao(DynamoDBMapper dynamoDBMapper, Clock clock) {
        return new PositionDao(dynamoDBMapper, clock);
    }

    @Bean Clock clock() {
        return Clock.systemUTC();
    }

    private static boolean isBlank(String str) {
        return str == null || str.trim().isEmpty();
    }

    @Bean
    public EnvoyAuditLog envoyAuditLog(Environment environment,
            @Qualifier("instanceName") String instanceName) throws UnknownHostException {
        LOG.info("Initialised audit logger: instance={}", instanceName);
        return new EnvoyAuditLog(environment.name(), EnvoyAuditComponents.TradeBookingService, instanceName);
    }

    @Bean(name = "instanceName")
    private static String instanceName() throws UnknownHostException {
        /* TODO: more effort to determine an instance name for this running service */
        return InetAddress.getLocalHost().getHostAddress();
    }

    @Bean
    public DataSource dataSource(@Value("${db.url}") String url,
                                 @Value("${db.username}") String username, @Value("${db.password}") String password) {
        DriverManagerDataSource dataSource = new DriverManagerDataSource(url, username, password);
        return dataSource;
    }

    @Bean
    public JdbcTemplate jdbcTemplate(DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }

    @Bean
    public CacheService cacheService(JdbcTemplate jdbcTemplate) {
        return new CacheService(jdbcTemplate, true);
    }

    @Bean
    public TraderUpdateCacheHandler traderUpdateCacheHandler(MsgLibConnection msgLibConnection, CacheService cacheService) {
        TraderUpdateCacheHandler handler = new TraderUpdateCacheHandler(cacheService);
        msgLibConnection.addMessageListener("*", MsgType.CrosstradeTraderDetails, handler);
        return handler;
    }

    @Bean
    public FirmUpdateCacheHandler firmUpdateCacheHandler(MsgLibConnection msgLibConnection, CacheService cacheService) {
        FirmUpdateCacheHandler handler = new FirmUpdateCacheHandler(cacheService);
        msgLibConnection.addMessageListener("*", MsgType.CrosstradeFirmDetails, handler);
        return handler;
    }

    @Bean
    public InstrumentUpdateCacheHandler instrumentUpdateCacheHandler(MsgLibConnection msgLibConnection, CacheService cacheService) {
        InstrumentUpdateCacheHandler handler = new InstrumentUpdateCacheHandler(cacheService);
        msgLibConnection.addMessageListener("*", MsgType.CrosstradeBond, handler);
        return handler;
    }

    @Bean
    public FxPairService fxPairService(@Qualifier("restTemplate") RestTemplate restTemplate,
                                       @Value("${crs.url}") String crsUrl) {
        return new FxPairService(restTemplate, crsUrl);
    }

    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }

}

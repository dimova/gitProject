package com.icap.truequote.crosstrade.execution.crs;

public class CRSException extends RuntimeException {
    public CRSException(String reason) {
        super(reason);
    }

    public CRSException(String reason, Throwable cause) {
        super(reason, cause);
    }
}

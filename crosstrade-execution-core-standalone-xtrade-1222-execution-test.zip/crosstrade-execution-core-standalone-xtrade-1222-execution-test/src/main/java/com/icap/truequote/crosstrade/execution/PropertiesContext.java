package com.icap.truequote.crosstrade.execution;

import com.icap.envoy.crosstrade.referencedata.api.Environment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PropertiesContext {

    private static final String ENV_SYSTEM_PROP_KEY = "env";
    private static final String DEFAULT_ENVIRONMENT = "local";

    private static final Logger LOG = LoggerFactory.getLogger(PropertiesContext.class);

    @Bean
    public Environment getEnvironment() {
        /* TODO: Environment enum should come from a common library */
        String env = System.getProperty(ENV_SYSTEM_PROP_KEY, DEFAULT_ENVIRONMENT);
        return Environment.valueOf(env.toUpperCase());
    }
}

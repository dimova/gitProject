package com.icap.truequote.crosstrade.execution.gtn;

import com.icap.envoy.crosstrade.api.Trade;
import com.icap.truequote.crosstrade.api.Trader;
import com.icap.truequote.crosstrade.service.CacheService;

import java.io.IOException;
import java.io.Writer;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.regex.Matcher;

import static com.icap.envoy.crosstrade.validation.SettlementDateValidator.SETTLEMENT_PATTERN;
import static java.lang.String.format;

public class GTNTradeAppender {

    private CacheService cacheService;
    private final String marketId;

    public static final String HEADER = "Index,MarketId,Isin,AmountUnit,Amount,PriceType,Price,CustomerNumber,Action,Commission Adjusted Price,Transactions,Time,Day To Settle,Settlement Currency,FX Rate";

    private DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("HHmmss"); // no timezone, crazy

    public GTNTradeAppender(CacheService cacheService, String marketId) {
        this.cacheService = cacheService;
        this.marketId = marketId;
    }

    public void append(Writer writer, List<Trade> trades, ZonedDateTime executionTime) throws IOException {
        writer.append(HEADER);
        writer.append("\n");

        String execTime = timeFormat.format(executionTime);

        for (Trade trade : trades) {
            /* TODO: optimise: all trades should have the same customer number */
            long customerNumber = getCustomerNumber(trade.getTraderId());

            writer.append(format("%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s",
                    trade.getOrderId(),
                    marketId,
                    trade.getIsin(),
                    AmountUnit.UNSCALED.toInt(),
                    trade.getSize(),
                    PriceType.DECIMAL.toInt(),
                    trade.getPrice().doubleValue(),
                    customerNumber,
                    getAction(trade).toInt(),
                    trade.getAdjustedPrice().doubleValue(),
                    1,
                    execTime,
                    getSettlement(trade),
                    trade.getSettlementCurrency(),
                    trade.getFxRate()));
            writer.append("\n");
        }
    }

    private long getCustomerNumber(String traderId) {
        Trader trader = cacheService.findTraderByTraderUID(traderId);
        if(trader == null) {
            throw new IllegalStateException(format("Unknown trader: (traderId=%s)", traderId));
        }
        return trader.getGtnAccountId();
    }

    private static Action getAction(Trade trade) {
        switch (trade.getSide()) {
            case BUY:
                return Action.BID;
            case SELL:
                return Action.OFFER;
        }
        throw new IllegalArgumentException(format("Trade side '%s' not supported.", trade.getSide()));
    }

    private static int getSettlement(Trade trade) {
        Matcher matcher = SETTLEMENT_PATTERN.matcher(trade.getSettlement());
        if (!matcher.matches()) {
            throw new IllegalArgumentException(format("Invalid format for settlement day: '%s'", trade.getSettlement()));
        }

        return Integer.parseInt(matcher.group(1));
    }

    enum PriceType {
        DECIMAL(5),
        ;
        private final int val;
        PriceType(int val) {
            this.val = val;
        }
        public int toInt() {
            return val;
        }
    }

    enum Action {
        BID(5),
        OFFER(6),
        ;
        private final int val;
        Action(int val) {
            this.val = val;
        }
        public int toInt() {
            return val;
        }
    }

    enum AmountUnit {
        UNSCALED(0),
        ;
        private final int val;
        AmountUnit(int val) {
            this.val = val;
        }
        public int toInt() {
            return val;
        }
    }
}

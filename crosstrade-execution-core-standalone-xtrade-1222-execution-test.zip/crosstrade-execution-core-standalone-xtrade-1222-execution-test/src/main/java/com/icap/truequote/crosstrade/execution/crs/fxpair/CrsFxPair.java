package com.icap.truequote.crosstrade.execution.crs.fxpair;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;

/**
 * Created by n_stojanov on 08/02/2018.
 */
public class CrsFxPair {

    private final String fromCurrencyCode;
    private final String toCurrencyCode;
    private final BigDecimal crossRate;

    public CrsFxPair(@JsonProperty("FromCurrencyCode") String fromCurrencyCode,
                     @JsonProperty("ToCurrencyCode") String toCurrencyCode,
                     @JsonProperty("XRate") BigDecimal crossRate) {
        this.fromCurrencyCode = fromCurrencyCode;
        this.toCurrencyCode = toCurrencyCode;
        this.crossRate = crossRate;
    }

    public String getFromCurrencyCode() {
        return fromCurrencyCode;
    }

    public String getToCurrencyCode() {
        return toCurrencyCode;
    }

    public BigDecimal getCrossRate() {
        return crossRate;
    }

}

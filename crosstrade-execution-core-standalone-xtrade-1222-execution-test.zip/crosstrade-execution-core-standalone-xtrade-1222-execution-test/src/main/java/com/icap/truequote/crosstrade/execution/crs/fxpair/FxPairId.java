package com.icap.truequote.crosstrade.execution.crs.fxpair;

import java.util.Objects;

/**
 * Created by n_stojanov on 08/02/2018.
 */
public class FxPairId {
    private final String baseCcy;
    private final String targetCcy;

    public FxPairId(String baseCcy, String targetCcy) {
        this.baseCcy = baseCcy;
        this.targetCcy = targetCcy;
    }

    public String getBaseCcy() {
        return baseCcy;
    }

    public String getTargetCcy() {
        return targetCcy;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FxPairId fxPairId = (FxPairId) o;
        return Objects.equals(baseCcy, fxPairId.baseCcy) &&
                Objects.equals(targetCcy, fxPairId.targetCcy);
    }

    @Override
    public int hashCode() {
        return Objects.hash(baseCcy, targetCcy);
    }

    @Override
    public String toString() {
        return "FxPairId{" +
                "baseCcy='" + baseCcy + '\'' +
                ", targetCcy='" + targetCcy + '\'' +
                '}';
    }
}

package com.icap.truequote.crosstrade.execution.crs;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CRSContext {

    @Bean
    public CRSService crs(
            CrsMsgLibFactory crsMsgLibFactory,
            @Value("${crs.systemName}") String systemName,
            @Value("${crs.heartBeatCheckIntervalSecs}") int heartBeatCheckInterval,
            @Value("${crs.heartBeatLogIntervalSecs}") int heartBeatLogIntervalSecs) {
        return new CRSService(systemName, crsMsgLibFactory, heartBeatCheckInterval, heartBeatLogIntervalSecs);
    }

    @Bean
    public CrsMsgLibFactory crsMsgLibFactory(@Value("${crs.host}") String host,
                                             @Value("${crs.port}") int port,
                                             @Value("${crs.username}") String username,
                                             @Value("${crs.password}") String password) {
        return new CrsMsgLibFactory(host, port, username, password);
    }
}

package com.icap.truequote.crosstrade.execution.crs.fxpair;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Created by n_stojanov on 08/02/2018.
 */
public class FxPair {
    private final FxPairId fxPairId;
    private final BigDecimal value;
    private final LocalDateTime createdAt;

    public FxPair(FxPairId fxPairId, BigDecimal value, LocalDateTime createdAt) {
        this.fxPairId = fxPairId;
        this.value = value;
        this.createdAt = createdAt;
    }

    public FxPairId getFxPairId() {
        return fxPairId;
    }

    public BigDecimal getValue() {
        return value;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
}

package com.icap.truequote.crosstrade.execution;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.icap.altex.MsgLib.MessageListener;
import com.icap.altex.MsgLib.MsgBase;
import com.icap.altex.MsgLib.messages.CrosstradeFixOrderExecution;
import com.icap.altex.MsgLib.messages.CrosstradePositionStatus;
import com.icap.altex.MsgLib.messages.CrosstradeTradeExecutions;
import com.icap.altex.MsgLib.messages.CrosstradeTradeStatus;
import com.icap.envoy.crosstrade.api.*;
import com.icap.envoy.crosstrade.auditing.EnvoyAuditLog;
import com.icap.envoy.crosstrade.dao.PositionDao;
import com.icap.envoy.crosstrade.dao.TradeDao;
import com.icap.fusion.altex.MsgLibConnection;
import com.icap.fusion.altex.MsgLibMessageSendException;
import com.icap.fusion.dynamo.response.WriteResponse;
import com.icap.fusion.sso.idp.api.sso.User;
import com.icap.fusion.sso.sp.api.session.SpSession;
import com.icap.truequote.crosstrade.api.Firm;
import com.icap.truequote.crosstrade.api.Instrument;
import com.icap.truequote.crosstrade.api.Trader;
import com.icap.truequote.crosstrade.execution.crs.CRSException;
import com.icap.truequote.crosstrade.execution.crs.CRSService;
import com.icap.truequote.crosstrade.execution.crs.FirmLimit;
import com.icap.truequote.crosstrade.execution.crs.fxpair.FxPairService;
import com.icap.truequote.crosstrade.execution.gtn.GTNService;
import com.icap.truequote.crosstrade.service.CacheService;
import com.icap.truequote.crosstrade.util.CommonUtils;
import com.icap.truequote.crosstrade.util.ConvertUtils;
import com.icap.truequote.crosstrade.util.MsgUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.ZonedDateTime;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;

import static com.icap.truequote.crosstrade.util.MsgUtil.EventLevel;
import static java.lang.String.format;
import static java.util.Arrays.asList;
import static java.util.Objects.requireNonNull;
import static java.util.concurrent.CompletableFuture.runAsync;
import static java.util.concurrent.TimeUnit.MILLISECONDS;
import static java.util.concurrent.TimeUnit.SECONDS;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toList;

public class TradeExecutionHandler implements MessageListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(TradeExecutionHandler.class);

    public static final int BROKER_RATE_PRECISION = 3;

    /* TODO: optimise this thread pool */
    private static final ExecutorService executor = new ThreadPoolExecutor(100, 500, 60, TimeUnit.SECONDS,
            new ArrayBlockingQueue<>(1000), new ThreadPoolExecutor.CallerRunsPolicy());

    private CRSService crs;
    private GTNService gtn;
    private TradeDao tradeDao;
    private PositionDao positionDao;
    private CacheService cacheService;
    private FxPairService fxPairService;
    private final String[] groups;
    private final MsgLibConnection msgLibConnection;

    /* TODO: should we use a concurrent hashmap instead of expiring cache for executing trades? */
    private Cache<String, BatchExecutionHandler> executingTrades;
    private int batchTimeout;

    private final EnvoyAuditLog envoyAuditLog;

    public TradeExecutionHandler(CRSService crs, GTNService gtn,
                                 TradeDao tradeDao, PositionDao positionDao,
                                 CacheService cacheService, FxPairService fxPairService,
                                 int batchTimeout, String groupNames,
                                 MsgLibConnection msgLibConnection, EnvoyAuditLog envoyAuditLog) {
        this.crs = crs;
        this.gtn = gtn;
        this.tradeDao = tradeDao;
        this.positionDao = positionDao;
        this.cacheService = cacheService;
        this.envoyAuditLog = envoyAuditLog;
        this.fxPairService = fxPairService;

        /* keep trades that are executing in memory for longer than their batchTimeout */
        this.executingTrades = initCache(batchTimeout * 2);
        this.batchTimeout = batchTimeout;
        this.groups = groupNames.split(",");
        this.msgLibConnection = msgLibConnection;
    }

    private static Cache initCache(int timeout) {
        return CacheBuilder.newBuilder()
                .expireAfterWrite(timeout, SECONDS)
                .build();
    }

    @Override
    public void OnMsg(MsgBase msg) {

        if(!(msg instanceof CrosstradeTradeExecutions)) {
            LOGGER.debug("Wrong message type: expected [{}], message: [{}]", CrosstradeTradeExecutions.class.getName(), msg);
            return;
        }
        CrosstradeTradeExecutions executions = (CrosstradeTradeExecutions) msg;
        Trader trader = cacheService.findTraderByTraderUID(executions.getTraderUID());
        if(trader == null) {
            LOGGER.error("No trader found with TraderUID: [{}]", executions.getTraderUID());
            return;
        }

        Collection<Trade> trades = ConvertUtils.executionTrades(executions);

        if(!trades.isEmpty()) {
            executeTrades(trader, trades);
        }

    }

    public void executeTrades(Trader trader, Collection<Trade> trades) {
        trades.forEach(trade -> {
            runAsync(() -> {

                if (isExecutionRequest(trade)) {
                    try {
                        processTrade(trader, trade);

                    } catch (TradeExecutionException e) {
                        updateTradeStatus(trader, ExecutionStatus.EXECUTION_FAILURE, null, trade);
                        LOGGER.error(String.format("Unable to process trade: %s", TradeMarshaller.str(trade)), e);
                        MsgUtil.sendClientEvent(trader,EventLevel.ERROR, "Unable to process trade" , e.getMessage(), this::sendMessage);
                    } catch (Exception e) {
                        updateTradeStatus(trader, ExecutionStatus.EXECUTION_FAILURE, null, trade);
                        LOGGER.error(String.format("Unable to process trade, unexpected error: %s", TradeMarshaller.str(trade)), e);
                        MsgUtil.sendClientEvent(trader,EventLevel.ERROR, "Unable to process trade", e.getMessage(), this::sendMessage);
                    }
                }
            }, executor);

        });
    }

    private static boolean isExecutionRequest(Trade trade) {
        return (trade.getStatus().equals(TradeStatus.EXECUTION_REQUESTED));
    }

    private void processTrade(Trader trader, Trade trade) {
        LOGGER.info("Processing trade: {}", TradeMarshaller.str(trade));
        try {
            submitToBatch(trader, trade);

        } catch (ExecutionException e) {
            throw new TradeExecutionException("Unable to execute trade.", e);
        }
    }

    /* TODO: synchronisation, good place to optimise; do something atomic */
    private synchronized void submitToBatch(Trader trader, Trade trade) throws ExecutionException {
        try {
            BatchExecutionHandler inProgress = executingTrades.get(
                    batchId(trade.getExecutionBatchId(), trade.getUserId()), () -> null);
            LOGGER.info("Batch in progress: batchId={}, size={}, userId={}",
                    trade.getExecutionBatchId(), trade.getExecutionBatchSize(), trade.getUserId());
            inProgress.put(trade);
            return;

        } catch (CacheLoader.InvalidCacheLoadException e) {
            /* keep going if there's nothing in cache */
            LOGGER.debug(e.getMessage(), e);
        }

        BatchExecutionHandler batch = new BatchExecutionHandler(trader, trade, trades -> execute(trader, trades));
        LOGGER.info("New batch created: batchId={}, size={}, userId={}",
                trade.getExecutionBatchId(), trade.getExecutionBatchSize(), trade.getUserId());
        executor.execute(batch);
        executingTrades.put(batchId(trade.getExecutionBatchId(), trade.getUserId()), batch);
    }

    private static String batchId(String batchId, String userId) {
        /* trades executing in a batch have the same batchId; pair with the userId for added assurance */
        return format("[%s][%s]", batchId, userId);
    }

    private boolean execute(Trader trader, List<Trade> trades) {
        /* TODO: validate that all trades have the same batch ID, and user/trader ID. We know that they do from upstream */
        Trade t = trades.get(0);
        String batchId = t.getExecutionBatchId();

        BigDecimal brokerRate = trader.getBrokerRate().setScale(BROKER_RATE_PRECISION, RoundingMode.HALF_EVEN);
        if (brokerRate == null) {
            throw new TradeExecutionException(format("Unknown broker rate: traderId=%s", trader.getTraderUID()));
        }
        trades.forEach(trade -> trade.setAdjustedPrice(adjustedPrice(trade, brokerRate)));

        if (exceedsLimit(trader, trades)) {
            updateTradeStatus(trader, ExecutionStatus.LIMIT_EXCEEDED, null, trades.toArray(new Trade[trades.size()]));
            String message = "Trade execution has failed - credit limit is exceeded";
            MsgUtil.sendClientEvent(trader, EventLevel.ERROR, message, null, this::sendMessage);
            return false;
        }
        ZonedDateTime executionTime = gtn.execute(trades);
        updateTradeStatus(trader, ExecutionStatus.EXECUTED, executionTime, trades.toArray(new Trade[trades.size()]));

        LOGGER.info("{} trades executed: batchId={}, orderIds={}", trades.size(), batchId, TradeMarshaller.str(trades, trade -> orderId(trade)));
        trades.forEach(trade -> envoyAuditLog.tradeSubmittedForExecution(trade));

        return true;
    }

    private Trader getTrader(String traderId) {
        Trader trader = cacheService.findTraderByTraderUID(traderId);
        LOGGER.info("Trader: {}", trader);
        return trader;
    }

    protected BigDecimal adjustedPrice(Trade trade, BigDecimal brokerRate) {
        /* for Envoy, the broker rate must be split in 2 because the trader sits on both sides */
        BigDecimal splitRate = brokerRate.divide(new BigDecimal(2));
        BigDecimal price = trade.getPrice();
        if (price == null) {
            throw new TradeExecutionException(format("Price not found: isin=%s", trade.getIsin()));
        }

        switch (trade.getSide()) {
            case BUY:
                price = price.add(splitRate);
                break;
            case SELL:
                price = price.subtract(splitRate);
                break;
            default:
                throw new TradeExecutionException("Trade side must be BUY or SELL.");
        }

        BigDecimal exchangeRate = getFxRate(trade);
        price = price.divide(exchangeRate, BigDecimal.ROUND_HALF_UP);

        return price.setScale(BROKER_RATE_PRECISION, RoundingMode.HALF_EVEN);
    }

    /**
     * Retrieve exchange rate from the CRS service for the given trade
     *
     * @param trade
     * @return
     */
    private BigDecimal getFxRate(Trade trade) {
        BigDecimal settlementRate = trade.getFxRate();
        if (settlementRate != null)
            return settlementRate;

        // Assume default value 1, so the TradeExecutionHandler is not aborted in the case of missing exchange rate
        BigDecimal fxRate = BigDecimal.ONE;

        String tradeCcy = getCurrencyCodeForTrade(trade);
        if (!StringUtils.isEmpty(tradeCcy)) {
            BigDecimal retrievedRate = fxPairService.getExchangeRate(tradeCcy);
            if (retrievedRate != null)
                fxRate = retrievedRate;
        }

        return fxRate;
    }

    /**
     * Get currency code for the specified Trade
     * trade.ccy - if the property is set
     * isinInstrument - if the trade.ccy property is not set, and valid ISIN Instrument exists
     *
     * @param trade
     * @return
     */
    private String getCurrencyCodeForTrade(Trade trade) {
        String tradeCcy = trade.getCcy();
        if (StringUtils.isEmpty(tradeCcy)) {
            String tradeIsin = trade.getIsin();
            if (!StringUtils.isEmpty(tradeIsin)) {
                Instrument tradeIsinInstrument = cacheService.findInstrumentByIsin(tradeIsin);
                if (tradeIsinInstrument != null)
                    tradeCcy = tradeIsinInstrument.getCcy();
            }
        }

        return tradeCcy;
    }

    private boolean exceedsLimit(Trader trader, List<Trade> trades) {
        /* TODO: validate that all trades came from the same firm. We now that they do from upstream */
        Trade t0 = trades.get(0);
        String batchId = t0.getExecutionBatchId();
        String firmId = t0.getFirmId();
        Firm firm = getFirm(firmId);

        String groupCode = firm.getGroupCode();
        try {
            FirmLimit limit = crs.fetchLimit(groupCode, batchId.toString());

            double total = trades.stream()
                    .map(trade -> trade.getAdjustedPrice()
                            .multiply(new BigDecimal(trade.getSize()))
                            .divide(new BigDecimal(100)))
                    .reduce(new BigDecimal(0), (subtotal, notional) -> subtotal.add(notional))
                    .doubleValue();

            LOGGER.debug("Checking credit limit: tradeTotal={}, batchId={}, firmId={}", total, batchId, firmId);
            boolean exceeds = total > limit.remainder;
            if (exceeds) {
                LOGGER.info(String.format("Firm would exceed its limit: groupCode=%s, remainder=%s, tradeTotal=%s orderIds=%s",
                        groupCode, limit.remainder, total, TradeMarshaller.str(trades, trade -> orderId(trade))));
            }

            return exceeds;

        } catch (CRSException e) {
            String message = format("Unable to fetch limit: group code=%s", groupCode);
            MsgUtil.sendClientEvent(trader, EventLevel.ERROR, message, null, this::sendMessage);
            throw new TradeExecutionException(message, e);
        }
    }

    private Firm getFirm(String firmId) {
        return cacheService.findFirmByFirmUID(firmId);
    }

    private void updateTradeStatus(Trader trader, ExecutionStatus status, ZonedDateTime executionTime, Trade... input) {
        Map<String, List<Trade>> tradesByUser = asList(input).parallelStream().collect(groupingBy(Trade::getUserId));
        tradesByUser.forEach((userId, trades) -> {
            ExecutionStatus executionStatus = status;
            trades.stream().forEach(trade -> {
                trade.setUserId(userId);
                trade.setExecutionStatus(status);
                if (ExecutionStatus.EXECUTED == status) {
                    trade.setExecutedAt(executionTime.toLocalDateTime());
                    requireNonNull(trade.getAdjustedPrice(), "Price was not adjusted.");
                } else {
                    unsetExecutedProperties(trade);
                }

                TradeStatus tradeStatus = tradeStatus(status);
                if (tradeStatus != null) {
                    trade.setStatus(tradeStatus);
                }
            });
            WriteResponse<Trade> fails = tradeDao.save(trades);
            if(!fails.getFailedItems().isEmpty()) {
                LOGGER.error("Failed to execute trades: [{}]", fails.getError());
                executionStatus = ExecutionStatus.EXECUTION_FAILURE;
                fails.getFailedItems().forEach(trade -> {
                    updateTradeStatus(trader, ExecutionStatus.EXECUTION_FAILURE, null, trades.toArray(new Trade[trades.size()]));
                });
                String error = String.format("Failed to save executed trade");
                String detailedMessage = String.format("Failed to save executed trade: [%s]", fails.getError());
                MsgUtil.sendClientEvent(trader.getTraderUID(), trader.getFirmUID(), EventLevel.ERROR, error, detailedMessage, this::sendMessage);
            }
            MsgUtil.updateTradeTopics(null, trades, this.groups, this::sendMessage, this::transform);
            updatePositionStatus(executionStatus, trades.toArray(new Trade[trades.size()]));
            trades.forEach(trade -> {
                if(isExecutedFixTrade(trade)) {
                    CrosstradeFixOrderExecution orderExecution = CommonUtils.tradeToFixOrderExecution(trade);
                    sendMessage(orderExecution);
                    LOGGER.info("Sent {} message: [{}]", CrosstradeFixOrderExecution.class.getSimpleName(), MsgUtil.getJSON(orderExecution));
                }
            });
        });
    }

    protected static boolean isExecutedFixTrade(Trade trade) {
        return TradeStatus.EXECUTED.equals(trade.getStatus()) && trade.getFixOrderId() != null;
    }

    public void transform(CrosstradeTradeStatus tradeStatus) {
        MsgUtil.transform(tradeStatus, cacheService);
    }

    private static void unsetExecutedProperties(Trade trade) {
        trade.setAdjustedPrice(null);
        trade.setExecutedAt(null);
    }

    private static TradeStatus tradeStatus(ExecutionStatus status) {
        switch (status) {
            case EXECUTED:
                return TradeStatus.EXECUTED;
            case LIMIT_EXCEEDED:
                return TradeStatus.PENDING;
            case EXECUTION_FAILURE:
                return TradeStatus.PENDING;
            default:
                return null;
        }
    }

    private void updatePositionStatus(ExecutionStatus status, Trade... input) {
        Map<String, List<Trade>> tradesByUser = asList(input).parallelStream().collect(groupingBy(Trade::getUserId));

        Map<String, List<Position>> positionsByUser = tradesByUser.entrySet().stream()
                .map(entry -> {
                    String userId = entry.getKey();
                    List<Trade> trades = entry.getValue();
                    Set<String> orderIds = new HashSet(trades.stream().map(Trade::getOrderId).collect(toList()));
                    return positionDao.findPositionByUserIdAndOrderIds(userId, orderIds);
                })
                .flatMap(Collection::stream)
                .map(Position.class::cast) // slow clap for java lambdas and static types
                .collect(groupingBy(Position::getUserId));

        positionsByUser.forEach((userId, position) -> {
            PositionMutations mutations = position.stream().collect(PositionMutations::new,
                    (mut, pos) -> {
                        if (pos == null) {
                            /* the position is already deleted (i.e. when either side of the trade has executed) */
                            if (ExecutionStatus.EXECUTED != status) {
                                throw new IllegalStateException(format("Position not found: orderId=%s", pos.getOrderId()));
                            }
                        }

                        if (ExecutionStatus.EXECUTED == status) {
                            mut.addMutation(WriteOperation.DELETE, pos);
                            return;
                        }

                        PositionStatus positionStatus = positionStatus(status);
                        if (positionStatus != null) {
                            pos.setStatus(positionStatus);
                        }

                        mut.addMutation(WriteOperation.UPDATE, pos);

                    },
                    (m1, m2) -> {
                        throw new UnsupportedOperationException("parallel position mutations no supported");
                    });
            SpSession session = toSession(userId);
            positionDao.delete(userId, mutations.getDeletes());
            positionDao.save(session.getUser(), mutations.getUpdates());

            MsgUtil.updatePositionTopics(mutations.getDeletes(), mutations.getUpdates(), this.groups, this::sendMessage, this::transform);
        });
    }

    private enum WriteOperation { UPDATE, DELETE }
    private class PositionMutations {
        private Map<WriteOperation, List<Position>> mutations;

        public PositionMutations() {
            mutations = new ConcurrentHashMap<>();
            mutations.put(WriteOperation.DELETE, new ArrayList<>());
            mutations.put(WriteOperation.UPDATE, new ArrayList<>());
        }

        public void addMutation(WriteOperation op, Position position) {
            mutations.get(op).add(position);
        }

        public List<Position> getDeletes() {
            return mutations.get(WriteOperation.DELETE);
        }

        public List<Position> getUpdates() {
            return mutations.get(WriteOperation.UPDATE);
        }
    }

    private static PositionStatus positionStatus(ExecutionStatus status) {
        switch (status) {
            case LIMIT_EXCEEDED:
                return PositionStatus.VALID;
            case EXECUTION_FAILURE:
                return PositionStatus.VALID;
            default:
                return null;
        }
    }

    private static SpSession toSession(String userId) {
        User user = new User();
        user.setId(userId);
        return new SpSession(null, null, null, user);
    }

    private static String orderId(Trade trade) {
        return format("%s:%s", trade.getSide(), trade.getOrderId());
    }

    private void sendMessage(MsgBase msg) {
        try {
            msgLibConnection.sendMessage(msg);
        } catch (MsgLibMessageSendException e) {
            LOGGER.error(e.getMessage(), e);
        }
    }

    private void transform(CrosstradePositionStatus status) {
        MsgUtil.transform(status, cacheService);
    }

    class BatchExecutionHandler implements Runnable {

        public final String id;
        public final String userId;
        public final int size;

        private final Trader trader;
        private final ArrayBlockingQueue<Trade> queue;
        private final Consumer<List<Trade>> consumer;

        public BatchExecutionHandler(Trader trader, Trade trade, Consumer<List<Trade>> consumer) {
            this.trader = trader;
            this.consumer = consumer;

            id = trade.getExecutionBatchId();
            userId = trade.getUserId();
            size = trade.getExecutionBatchSize();
            queue = new ArrayBlockingQueue<>(size);

            if (size < 1) {
                throw new TradeExecutionException("Could not establish trade batch, size < 1");
            }

            queue.offer(trade);
        }

        public void put(Trade trade) {
            validate(trade);
            if (!queue.offer(trade)) {
                throw new TradeExecutionException(
                        String.format("Could not execute trade, exceeded expected batch size: batchSize=%s, trade=%s",
                                size, TradeMarshaller.str(trade)));
            }
        }

        private void validate(Trade trade) {
            if (!id.equals(trade.getExecutionBatchId())) {
                throw new TradeExecutionException(
                        String.format("Could not execute trade. Batch ID did not match: batchId=%, trade=%s", id, TradeMarshaller.str(trade)));
            }

            if (!userId.equals(trade.getUserId())) {
                throw new TradeExecutionException(
                        String.format("Cannot execute trade. User did not match: userId=%s, trade=%s", userId, TradeMarshaller.str(trade)));
            }

            if (size != trade.getExecutionBatchSize()) {
                throw new TradeExecutionException(
                        String.format("Could not execute trade. Batch size did not match: batchSize=%s, trade=%s", size, TradeMarshaller.str(trade)));
            }
        }

        @Override
        public void run() {
            try {
                List<Trade> trades = new ArrayList<>();
                LOGGER.info("Waiting for {} trades in the batch: batchId={}, userId={}", size, id, userId);

                long start = System.currentTimeMillis();
                long elapsed = 0;
                long timeout = batchTimeout * 1000;
                for (int i = 0; i < size; i++) {
                    Trade trade = queue.poll(timeout - elapsed, MILLISECONDS);
                    elapsed = System.currentTimeMillis() - start;

                    if (trade == null) {
                        updateTradeStatus(trader, ExecutionStatus.EXECUTION_FAILURE, null, trades.toArray(new Trade[trades.size()]));
                        throw new TradeExecutionException(
                                String.format("Batch timed out after %s secs, expected [%s] trades, got [%s]: batchId=%s, userId=%s, trades=%s",
                                        (elapsed / 1000), size, trades.size(), id, userId, TradeMarshaller.str(trades, t -> orderId(t))));
                    }
                    trades.add(trade);
                }
                LOGGER.info("All trades received: batchId={}, userId={}, elapsedTime={}ms", id, userId, elapsed);

                try {
                    consumer.accept(trades);

                } catch (TradeExecutionException e) {
                    String message = String.format("Execution failure: orderIds=%s", TradeMarshaller.str(trades, trade -> orderId(trade)));
                    LOGGER.error(message, e);
                    MsgUtil.sendClientEvent(trader, EventLevel.ERROR, message, e.getMessage(), TradeExecutionHandler.this::sendMessage);
                    updateTradeStatus(trader, ExecutionStatus.EXECUTION_FAILURE, null, trades.toArray(new Trade[trades.size()]));

                } catch (Exception e) {
                    String message = String.format("Unexpected execution failure: orderIds=%s", TradeMarshaller.str(trades, trade -> orderId(trade)));
                    LOGGER.error(message, e);
                    MsgUtil.sendClientEvent(trader, EventLevel.ERROR, message, e.getMessage(), TradeExecutionHandler.this::sendMessage);
                    updateTradeStatus(trader, ExecutionStatus.EXECUTION_FAILURE, null, trades.toArray(new Trade[trades.size()]));
                }

            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new TradeExecutionException("Could not execute trade.", e);
            }
            /* removes itself from the cache once it's done executing */
            executingTrades.invalidate(batchId(id, userId));
        }
    }
}

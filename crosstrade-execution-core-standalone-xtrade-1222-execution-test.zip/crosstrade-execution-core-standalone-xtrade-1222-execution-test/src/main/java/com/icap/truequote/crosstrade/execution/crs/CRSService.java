package com.icap.truequote.crosstrade.execution.crs;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.icap.altex.MsgLib.ConnectionListener;
import com.icap.altex.MsgLib.MessageListener;
import com.icap.altex.MsgLib.MsgBase;
import com.icap.altex.MsgLib.MsgLib;
import com.icap.altex.MsgLib.enums.MsgType;
import com.icap.altex.MsgLib.messages.CRSLimit;
import com.icap.altex.MsgLib.messages.CRSLimitRequest;
import com.icap.altex.MsgLib.messages.CRSSystemLimit;
import com.icap.altex.MsgLib.messages.HeartBeat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

import static java.lang.String.format;
import static java.util.concurrent.TimeUnit.SECONDS;

public class CRSService {

    private static Logger LOG = LoggerFactory.getLogger(CRSService.class);

    private static final int MAX_SEND_ATTEMPTS = 10;

    private static int MAX_REQUEST_ATTEMPTS = 10;
    private static int MAX_RESPONSE_WAIT = 2;

    private final long HEARTBEAT_MAX_SILENCE = 20;
    private final long heartBeatLogInterval;
    private final long heartBeatCheckInterval;
    private AtomicLong lastHeartBeat;

    private final String systemName;
    private final CrsMsgLibFactory msgLibFactory;

    private ConnectionMonitor connMonitor;
    private Cache<String, CRSChannel> cache;
    private MsgLib msglib;

    public CRSService(String systemName, CrsMsgLibFactory msgLibFactory,
                      int heartBeatCheckInterval, int heartBeatLogInterval) {

        this.systemName = systemName;
        this.msgLibFactory = msgLibFactory;
        this.heartBeatCheckInterval = heartBeatCheckInterval;
        this.heartBeatLogInterval = heartBeatLogInterval;

        cache = newCache();
        try {
            msglib = newMsgLib();

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new CRSException("Unable to initialise MsgLib, thread interrupted.", e);
        }
        connMonitor = new ConnectionMonitor();
        connMonitor.start();
    }

    private static Cache<String, CRSChannel> newCache() {
        /* TODO: configurable cache object TTL */
        return CacheBuilder.newBuilder().expireAfterWrite(300, TimeUnit.SECONDS).build();
    }

    protected void setMaxRequestAttempts(int attempts) {
        this.MAX_REQUEST_ATTEMPTS = attempts;
    }

    public FirmLimit fetchLimit(String groupCode, String requestId) {
        int attempts = 0;
        while (attempts++ < MAX_REQUEST_ATTEMPTS) {
            CRSChannel channel = sendRequest(groupCode, requestId);
            LOG.info(format("CRS request: systemName=%s, groupCode=%s, requestId=%s", systemName, groupCode, requestId));
            try {
                FirmLimit limit = channel.take();

                if (limit != null) {
                    LOG.info(format("CRS response: attempts=%s, systemName=%s, groupCode=%s, limit=%,d, remainder=%,d, requestId=%s",
                            attempts, systemName, groupCode, limit.limit, limit.remainder, requestId));
                    LOG.debug("CRS elapsed time: {} ms", channel.elapsedTime());
                    return limit;
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new CRSException(
                        format("Unable to take limit, thread interrupted: systemName=%s, groupCode=%s, requestId=%s",
                                systemName, groupCode, requestId), e);
            }
        }
        throw new CRSException(
                format("Could not get response, is limit defined? systemName=%s, groupCode=%s, requestId=%s, attempts=%s",
                        systemName, groupCode, requestId, --attempts));
    }

    protected CRSChannel sendRequest(String groupCode, String requestId) {
        CRSLimitRequest req = new CRSLimitRequest();
        req.setRequestId(requestId);
        req.setGroupCode(groupCode);
        req.setSystemName(systemName);

        CRSChannel channel = newChannel(requestId, groupCode);
        channel.startTimer();
        try {
            int attempts = 0;
            while (attempts++ < MAX_SEND_ATTEMPTS) {
                try {
                    checkConnection();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    LOG.error("Connection check failed, thread interrupted", e);
                }
                if (msglib != null && msglib.isConnected() && req.SendMessage(msglib)) {
                    LOG.info("Message sent after {} attempt(s): requestId={}", attempts, requestId);
                    break;
                }
            }
            if (attempts >= MAX_SEND_ATTEMPTS) {
                LOG.warn(format("Could not send CRS request, max attempts (%s) exceeded: systemName=%s, groupCode=%s, requestId=%s",
                        MAX_SEND_ATTEMPTS, systemName, groupCode, requestId));
            }

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            throw new CRSException(format("Could not send CRS request: systemName=%s, groupCode=%s, requestId=%s",
                    systemName, groupCode, requestId), e);
        }
        return channel;
    }

    class CRSLimitListener implements MessageListener {

        @Override
        public void OnMsg(MsgBase msg) {
            LOG.info("Received new CRSLimit message: {}", msg.EncodeToJSON());
            CRSLimit crsLimit = (CRSLimit) msg;
            String requestId = crsLimit.getRequestId();
            String groupCode = crsLimit.getGroupCode();
            CRSChannel channel = getChannel(requestId, groupCode);

            /* return if it's not a response that I've asked for */
            if (channel == null) {
                return;
            }

            for (CRSSystemLimit limit : crsLimit.getSystemLimitList()) {
                FirmLimit firmLimit = new FirmLimit(limit.getSystemName(), groupCode,
                        limit.getInitialMarginLimit(), limit.getInitialMarginRemainder());

                if (!systemName.equalsIgnoreCase(firmLimit.systemName)) {
                    continue;
                }

                try {
                    if (!channel.put(firmLimit)) {
                        LOG.error(format("Could not respond in time: systemName=%s, groupCode=%s, requestId=%s, limit=%s, remainder=%s",
                                systemName, groupCode, requestId, limit.getInitialMarginLimit(), limit.getInitialMarginRemainder()));
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    LOG.error("Could not respond with limit, thread interrupted", e);
                }
            }
        }
    }

    CRSChannel newChannel(String requestId, String groupCode) {
        CRSChannel channel = new CRSChannel(new ArrayBlockingQueue<>(10, true));
        cache.put(format("%s/%s", requestId, groupCode), channel);
        return channel;
    }

    /* Returns a channel from which to take a response for the specified requestId and groupCode */
    CRSChannel getChannel(String requestId, String groupCode) {
        try {
            return cache.get(format("%s/%s", requestId, groupCode), () -> null);

        } catch (ExecutionException e) {
            throw new CRSException("Unable to fetch limit.", e);
        } catch (CacheLoader.InvalidCacheLoadException e) {
            return null;
        }
    }



    class CRSChannel {

        public final ArrayBlockingQueue<FirmLimit> queue;
        private long startTime;

        CRSChannel(ArrayBlockingQueue<FirmLimit> queue) {
            this.queue = queue;
        }

        void startTimer() {
            this.startTime = System.currentTimeMillis();
        }

        long elapsedTime() {
            return System.currentTimeMillis() - startTime;
        }

        boolean put(FirmLimit limit) throws InterruptedException {
            return queue.offer(limit, MAX_RESPONSE_WAIT, SECONDS);
        }

        FirmLimit take() throws InterruptedException {
            return queue.poll(MAX_RESPONSE_WAIT, SECONDS);
        }
    }

    class HeartBeatListener implements MessageListener {

        private AtomicLong lastLog = new AtomicLong(0);

        HeartBeatListener() {
            lastHeartBeat = new AtomicLong(System.currentTimeMillis());
        }

        @Override
        public void OnMsg(MsgBase msg) {
            HeartBeat heartBeat = (HeartBeat) msg;
            long now = System.currentTimeMillis();
            lastHeartBeat.set(now);

            if (now - lastLog.get() > heartBeatLogInterval * 1000) {
                LOG.debug("Message bus heart beat: uid={}, topic={}, interval={}s",
                        heartBeat.getUid(), heartBeat.topic, heartBeat.getInterval() / 1000);
                lastLog.set(now);
            }
        }
    }

    class ConnectionMonitor extends Thread {
        @Override
        public void run() {
            LOG.info("Initialising connection monitoring: check interval={}", heartBeatCheckInterval);
            while (true) {
                try {
                    LOG.debug("Checking Msglib connection...");
                    checkConnection();
                    Thread.sleep(heartBeatCheckInterval * 1000);

                } catch (InterruptedException e) {
                    LOG.error("Connection monitoring has been stopped.", e);
                } catch (Exception e) {
                    LOG.error(format("Exception while monitoring the MsgLib connection: %s", e.getMessage()), e);
                }
            }
        }
    }

    private void checkConnection() throws InterruptedException {
        long now = System.currentTimeMillis();
        if (lastHeartBeat != null && now - lastHeartBeat.get() > HEARTBEAT_MAX_SILENCE * 1000) {
            LOG.warn("{} seconds elapsed without a heart beat. Re-initialising connection to message bus.", HEARTBEAT_MAX_SILENCE);
            try {
                msglib.close();
            } catch (IOException e) {
                LOG.error("Unable to close connection", e);
            }
            msglib = newMsgLib();
        }
    }

    protected MsgLib newMsgLib() throws InterruptedException {
        CRSConnectionListener connectionListener = new CRSConnectionListener();
        MsgLib msglib = msgLibFactory.getMsgLib(connectionListener);
        connectionListener.awaitOnConnected();
        return msglib;
    }

    class CRSConnectionListener implements ConnectionListener {
        private CountDownLatch latch;
        public CRSConnectionListener() { latch = new CountDownLatch(1); }
        public void awaitOnConnected() throws InterruptedException { latch.await(30, TimeUnit.SECONDS); }

        @Override
        public void onConnected(MsgLib msgLib) {
            LOG.info("CRS connection established.");
            try {
                msgLib.addMessageListener("*", MsgType.CRSLimit, new CRSLimitListener());
                msgLib.addMessageListener("*", MsgType.HeartBeat, new HeartBeatListener());
                LOG.info("CRS listener ready.");
            } catch (Exception e) {
                throw new CRSException("Listener could not attach.", e);
            } finally {
                LOG.info("countDown");
                latch.countDown();
            }
        }

        @Override
        public void onDisconnected(MsgLib msgLib, Exception e) {
            LOG.error("CRS connection disconnected.", e);
        }
    }
}

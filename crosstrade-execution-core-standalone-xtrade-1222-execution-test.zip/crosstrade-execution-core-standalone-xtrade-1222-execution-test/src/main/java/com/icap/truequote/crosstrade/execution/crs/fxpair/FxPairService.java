package com.icap.truequote.crosstrade.execution.crs.fxpair;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.client.RestTemplate;

import javax.annotation.PostConstruct;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Map;

/**
 * Created by n_stojanov on 08/02/2018.
 */
public class FxPairService {

    private static final Logger LOGGER = LoggerFactory.getLogger(FxPairService.class);
    private static final String USD_CCY_CODE = "USD";

    private final RestTemplate restTemplate;
    private final String restUrl;

    private Map<FxPairId, FxPair> fxPairs;

    public FxPairService(RestTemplate restTemplate, String restUrl) {
        this.restTemplate = restTemplate;
        this.restUrl = restUrl;
    }

    public BigDecimal getExchangeRate(String currencyCode) {
        if (fxPairs == null)
            initFxPairs();

        FxPairId fxPairId = new FxPairId(currencyCode, USD_CCY_CODE);
        if (fxPairs.containsKey(fxPairId))
            return fxPairs.get(fxPairId).getValue();
        else
            return null;
    }

    @PostConstruct
    public void setup() {
        initFxPairs();
    }

    /**
     * Refresh FX Rates hourly
     */
    @Scheduled(cron = "0 0 * * * ?")
    public void refreshFxRates() {
        initFxPairs();
    }

    private synchronized void initFxPairs() {
        LOGGER.info("Requesting fx pairs.");
        CrsFxPairList crossRates = restTemplate.getForObject(restUrl, CrsFxPairList.class);
        LOGGER.info("Received [{}] cross rates.", crossRates != null ? crossRates.getCrossRates().size() : 0);
        fxPairs = parseCrossRates(crossRates);
    }

    private Map<FxPairId, FxPair> parseCrossRates(CrsFxPairList crossRates) {
        if (crossRates == null) {
            return ImmutableMap.of();
        }

        Map<FxPairId, FxPair> fxPairMap = Maps.newHashMap();
        LocalDateTime now = LocalDateTime.now();
        for (CrsFxPair crsFxPair : crossRates.getCrossRates()) {
            FxPairId fxPairId = new FxPairId(crsFxPair.getFromCurrencyCode(), crsFxPair.getToCurrencyCode());
            FxPair fxPair = new FxPair(fxPairId,
                    crsFxPair.getCrossRate(),
                    now);
            fxPairMap.put(fxPairId, fxPair);
        }

        // Add USD -> USD rate.
        FxPairId id = new FxPairId(USD_CCY_CODE, USD_CCY_CODE);
        FxPair value = new FxPair(id, BigDecimal.valueOf(1), LocalDateTime.now());
        fxPairMap.put(id, value);

        return ImmutableMap.copyOf(fxPairMap);
    }
}

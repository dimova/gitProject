package com.icap.truequote.crosstrade.handler.instrument;

import com.icap.altex.MsgLib.MessageListener;
import com.icap.altex.MsgLib.MsgBase;
import com.icap.altex.MsgLib.messages.CrosstradeBond;
import com.icap.truequote.crosstrade.api.Instrument;
import com.icap.truequote.crosstrade.handler.firm.FirmUpdateCacheHandler;
import com.icap.truequote.crosstrade.service.CacheService;
import com.icap.truequote.crosstrade.util.ConvertUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Listener for Instrument details message
 */
public class InstrumentUpdateCacheHandler implements MessageListener {

    private static final Logger LOGGER = LogManager.getLogger(FirmUpdateCacheHandler.class);

    private final CacheService cacheService;

    public InstrumentUpdateCacheHandler(CacheService cacheService) {
        this.cacheService = cacheService;
    }

    @Override
    public void OnMsg(MsgBase msg) {
        CrosstradeBond bond = (CrosstradeBond) msg;
        Instrument instrument = ConvertUtils.toInstrument(bond);
        cacheService.addInstrument(instrument);
    }
}

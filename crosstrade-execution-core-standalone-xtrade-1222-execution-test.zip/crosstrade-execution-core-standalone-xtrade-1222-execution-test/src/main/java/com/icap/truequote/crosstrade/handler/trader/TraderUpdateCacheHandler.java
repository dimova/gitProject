package com.icap.truequote.crosstrade.handler.trader;

import com.icap.altex.MsgLib.MessageListener;
import com.icap.altex.MsgLib.MsgBase;
import com.icap.altex.MsgLib.messages.CrosstradeTraderDetails;
import com.icap.truequote.crosstrade.api.Trader;
import com.icap.truequote.crosstrade.service.CacheService;
import com.icap.truequote.crosstrade.util.ConvertUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Listener for Trader details message
 */
public class TraderUpdateCacheHandler implements MessageListener {

    private static final Logger LOGGER = LogManager.getLogger(TraderUpdateCacheHandler.class);

    private final CacheService cacheService;

    public TraderUpdateCacheHandler(CacheService cacheService) {
        this.cacheService = cacheService;
    }

    @Override
    public void OnMsg(MsgBase msg) {
        CrosstradeTraderDetails traderDetails = (CrosstradeTraderDetails) msg;
        Trader trader = ConvertUtils.toTrader(traderDetails);
        cacheService.addTrader(trader);
        LOGGER.info("Updated trader [{}]", trader);
    }
}

package com.icap.truequote.crosstrade.execution.crs;

public class FirmLimit {
    public final String systemName;
    public final String groupName;
    public final Long limit;
    public final Long remainder;

    public FirmLimit(String systemName, String groupName, Long limit, Long remainder) {
        this.systemName = systemName;
        this.groupName = groupName;
        this.limit = limit;
        this.remainder = remainder;
    }
}

package com.icap.truequote.crosstrade.execution;

import com.google.gson.Gson;
import com.icap.envoy.crosstrade.api.ExecutionStatus;
import com.icap.envoy.crosstrade.api.Trade;
import com.icap.envoy.crosstrade.api.TradeSide;
import com.icap.envoy.crosstrade.api.TradeStatus;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import static java.lang.String.format;
import static java.lang.String.join;
import static java.util.stream.Collectors.toList;

public class TradeMarshaller {
    private static Gson gson = new Gson();

    /* TODO: the Trade object should actually have a proper toString method */
    public static String str(Trade trade) {
        return gson.toJson(trade);
    }

    public static String str(List<Trade> trades, Function<? super Trade, String> fn) {
        return format("[%s]", join(", ", trades.stream().map(fn).collect(toList())));
    }

    /* TODO: this unmarshalling the object should really be in swiftt-core */
    public static Trade toTrade(Map<String, Object> obj) {
        Trade trade = new Trade();
        trade.setId(getValue(obj, "id", String.class));
        trade.setUserId(getValue(obj, "userId", String.class));
        trade.setTraderId(getValue(obj, "traderId", String.class));
        trade.setOrderId(getValue(obj, "orderId", String.class));
        trade.setFirmId(getValue(obj, "firmId", String.class));
        trade.setPrice(getValue(obj, "price", BigDecimal.class));
        trade.setAdjustedPrice(getValue(obj, "adjustedPrice", BigDecimal.class));
        trade.setSide(getEnumValue(obj, "side", TradeSide.class));
        trade.setStatus(getEnumValue(obj, "status", TradeStatus.class));
        trade.setIsin(getValue(obj, "isin", String.class));
        trade.setSize(getValue(obj, "size", Integer.class));
        trade.setSettlement(getValue(obj, "settlement", String.class));
        trade.setAddedAt(getValue(obj, "addedAt", LocalDateTime.class));
        trade.setExecutedAt(getValue(obj, "executedAt", LocalDateTime.class));
        trade.setExecutedAt(getValue(obj, "updatedAt", LocalDateTime.class));
        trade.setExecutionBatchId(getValue(obj, "executionBatchId", String.class));
        trade.setExecutionBatchSize(getValue(obj, "executionBatchSize", Integer.class));
        trade.setExecutionStatus(getEnumValue(obj, "executionStatus", ExecutionStatus.class));

        return trade;
    }

    private static <T> T getValue(Map<String, Object> map, String name, Class<T> c) {
        /* this is slightly awkward because the values that come from upstream are
         * all String types. Here we have some type coercion shenanigans.
         */
        Object val = map.get(name);
        if (val == null)
            return null;

        String strVal = (String) val;
        if (c.isAssignableFrom(String.class))
            return (T) strVal;

        if (c.isAssignableFrom(Integer.class))
            return (T) Integer.valueOf(strVal);

        if (c.isAssignableFrom(BigDecimal.class))
            return (T) new BigDecimal(strVal);

        if (c.isAssignableFrom(LocalDateTime.class))
            return (T) LocalDateTime.parse(strVal, DateTimeFormatter.ISO_DATE_TIME);

        throw new IllegalArgumentException(format("Unsupported type coercion: %s", c.getName()));
    }

    private static <E extends Enum<E>> E getEnumValue(Map<String, Object> map, String name, Class<E> c) {
        String value = (String) map.get(name);
        return (value != null) ? Enum.valueOf(c, value) : null;
    }
}

package com.icap.truequote.crosstrade.execution.gtn;

import com.icap.envoy.crosstrade.api.Trade;
import com.icap.truequote.crosstrade.execution.TradeExecutionException;
import com.icap.truequote.crosstrade.execution.TradeMarshaller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Clock;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;

import static java.lang.String.format;

public class GTNService {

    private static final String TEMP_DIR = System.getProperty("java.io.tmpdir");

    private GTNTradeAppender GTNTradeAppender;
    private String targetPath;
    private Clock clock;

    private static Logger LOG = LoggerFactory.getLogger(GTNService.class);

    public GTNService(GTNTradeAppender GTNTradeAppender, String path, Clock clock) {
        this.GTNTradeAppender = GTNTradeAppender;
        this.clock = clock;

        if (path != null && !path.trim().isEmpty())
            this.targetPath = path;

        LOG.info(format("Working path: %s", TEMP_DIR));
        LOG.info(format("GTN target path: %s", targetPath));
    }

    public ZonedDateTime execute(List<Trade> trades) {
        /* TODO: validate that the trades are buy/sell pairs */
        String filename = format("%s%senvoy_trades_out_%s.csv", TEMP_DIR, File.separator, UUID.randomUUID());
        ZonedDateTime executionTime = ZonedDateTime.now(clock);
        try {
            writeToFile(filename, executionTime, trades);

        } catch (FileNotFoundException e) {
            throw new TradeExecutionException(
                    format("File not found: %s; cannot execute trades: orderIds=%s",
                            filename, TradeMarshaller.str(trades, trade -> trade.getOrderId())), e);

        } catch (UnsupportedEncodingException e) {
            throw new IllegalArgumentException("Unsupported file encoding. Use UTF-8.", e);

        }

        try {
            if (targetPath != null) {
                moveFile(filename, targetPath);
                LOG.info("{} trades handed off to GTN: executionTime={}, trades={}",
                        trades.size(), executionTime, TradeMarshaller.str(trades, trade -> trade.getOrderId()));

            } else {
                LOG.warn("Trades file target path not set. Running in dev mode?");
            }
            return executionTime;

        } catch (IOException e) {
            throw new TradeExecutionException(
                    format("Could not move file to GTN target path: (filename=%s, target=%s); cannot execute trades: %s",
                            filename, targetPath, TradeMarshaller.str(trades, trade -> trade.getOrderId())), e);
        }
    }

    protected void writeToFile(String filename, ZonedDateTime executionTime, List<Trade> trades)
            throws FileNotFoundException, UnsupportedEncodingException {

        Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(filename), "utf-8"));
        try {
            GTNTradeAppender.append(writer, trades, executionTime);

        } catch (IOException e) {
            throw new TradeExecutionException(format("Could not write trades to file, I/O problem: file=%, trades=%s",
                    filename, TradeMarshaller.str(trades, t -> str(t))), e);

        } finally {
            try {
                writer.close();
                LOG.info("Trade was staged: file={}, trades={}", filename, TradeMarshaller.str(trades, t -> str(t)));

            } catch (IOException e) {
                LOG.warn(format("Could not close file: %s", filename));
            }
        }
    }

    private static String str(Trade t) {
        return format("(orderId:%s, side:%s, trader:%s)", t.getOrderId(), t.getSide(), t.getTraderId());
    }

    private static void moveFile(String file, String targetPath) throws IOException {
        Path source = new File(file).toPath();
        Path target = new File(targetPath).toPath().resolve(source.getFileName());
        Files.copy(source, target, StandardCopyOption.REPLACE_EXISTING);
    }
}

package com.icap.truequote.crosstrade.execution.crs.fxpair;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.collect.Lists;

import java.util.List;

/**
 * Created by n_stojanov on 08/02/2018.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class CrsFxPairList {

    @JsonProperty("d")
    private List<CrsFxPair> crossRates = Lists.newArrayList();

    public List<CrsFxPair> getCrossRates() {
        return crossRates;
    }

    public void setCrossRates(List<CrsFxPair> crossRates) {
        this.crossRates = crossRates;
    }
}

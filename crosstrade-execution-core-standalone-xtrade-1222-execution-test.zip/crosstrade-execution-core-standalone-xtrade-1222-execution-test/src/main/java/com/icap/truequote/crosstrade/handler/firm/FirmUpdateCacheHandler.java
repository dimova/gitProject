package com.icap.truequote.crosstrade.handler.firm;

import com.icap.altex.MsgLib.MessageListener;
import com.icap.altex.MsgLib.MsgBase;
import com.icap.altex.MsgLib.messages.CrosstradeFirmDetails;
import com.icap.truequote.crosstrade.api.Firm;
import com.icap.truequote.crosstrade.service.CacheService;
import com.icap.truequote.crosstrade.util.ConvertUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Listener for Firm details message
 */
public class FirmUpdateCacheHandler implements MessageListener {

    private static final Logger LOGGER = LogManager.getLogger(FirmUpdateCacheHandler.class);

    private final CacheService cacheService;

    public FirmUpdateCacheHandler(CacheService cacheService) {
        this.cacheService = cacheService;
    }

    @Override
    public void OnMsg(MsgBase msg) {
        CrosstradeFirmDetails firmDetails = (CrosstradeFirmDetails) msg;
        Firm firm = ConvertUtils.toFirm(firmDetails);
        cacheService.addFirm(firm);
    }

}

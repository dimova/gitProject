package com.icap.truequote.crosstrade.execution;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.kms.AWSKMS;
import com.amazonaws.services.kms.AWSKMSClient;
import com.google.common.base.Strings;
import com.icap.fusion.dynamo.EnvironmentAwareDynamoDbMapper;
import com.icap.fusion.dynamo.PrefixedDynamoDb;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AwsContext {

    @Bean
    public ClientConfiguration clientConfiguration(@Value("${aws.proxy.host:}") String proxyHost,
                                                   @Value("${aws.proxy.port:0}") int proxyPort) {
        ClientConfiguration configuration = new ClientConfiguration();
        if (!Strings.isNullOrEmpty(proxyHost)) {
            configuration.setProxyHost(proxyHost);
            configuration.setProxyPort(proxyPort);
        }
        return configuration;
    }

    @Bean
    public Region region(@Value("${aws.region}") String region) {
        return Region.getRegion(Regions.fromName(region));
    }

    @Bean
    public AWSKMS kmsClient(@Qualifier("clientConfiguration") ClientConfiguration configuration,
                            @Qualifier("region") Region region) {
        return new AWSKMSClient(configuration).withRegion(region);
    }

    @Bean
    public AmazonDynamoDB dynamoDBClient(@Qualifier("clientConfiguration") ClientConfiguration configuration,
                                         @Qualifier("region") Region region,
                                         @Value("${dynamodb.endpoint:}") String dynamodbEndpoint) {

        // local database - for local development only
        if(!Strings.isNullOrEmpty(dynamodbEndpoint)) {
            AmazonDynamoDB dbLocalClient = new AmazonDynamoDBClient();
            dbLocalClient.setEndpoint(dynamodbEndpoint);
            return dbLocalClient;
        }

        return new AmazonDynamoDBClient(configuration).withRegion(region);
    }

    @Bean
    public DynamoDBMapper dynamoDBMapper(@Value("${aws.prefix}") String prefix,
                                         @Qualifier("dynamoDBClient") AmazonDynamoDB dynamoDB) {
        return new EnvironmentAwareDynamoDbMapper(prefix, dynamoDB).getDbMapper();
    }

    @Bean
    public PrefixedDynamoDb prefixedDynamoDb(@Value("${aws.prefix}") String prefix,
                                             @Qualifier("dynamoDBClient") AmazonDynamoDB dynamoDB) {
        return new PrefixedDynamoDb(prefix, new DynamoDB(dynamoDB));
    }
}

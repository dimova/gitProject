package com.icap.truequote.crosstrade.execution;

import com.icap.fusion.crypto.CryptoService;
import com.icap.fusion.crypto.FusionCryptoService;
import org.jasypt.encryption.StringEncryptor;
import org.jasypt.spring31.properties.EncryptablePropertySourcesPlaceholderConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;

/**
 *
 */
@Configuration
public class TestContext {

    @Bean
    public PropertySourcesPlaceholderConfigurer placeholderConfigurer(StringEncryptor stringEncryptor) {
        PropertySourcesPlaceholderConfigurer configurer = new EncryptablePropertySourcesPlaceholderConfigurer(stringEncryptor);
        configurer.setLocations(new ClassPathResource("integration-test.properties"));
        return configurer;
    }

    @Bean
    public CryptoService cryptoService() {
        return new FusionCryptoService();
    }

    @Bean
    public StringEncryptor stringEncryptor(CryptoService cryptoService) {
        return new StringEncryptor() {
            @Override
            public String encrypt(String message) {
                return cryptoService.encrypt(message);
            }

            @Override
            public String decrypt(String encryptedMessage) {
                return cryptoService.decrypt(String.format("ENC(%s)", encryptedMessage));
            }
        };
    }

}

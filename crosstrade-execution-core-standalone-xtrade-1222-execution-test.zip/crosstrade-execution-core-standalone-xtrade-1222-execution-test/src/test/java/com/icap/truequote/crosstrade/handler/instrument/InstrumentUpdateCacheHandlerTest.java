package com.icap.truequote.crosstrade.handler.instrument;

import com.icap.altex.MsgLib.messages.CrosstradeBond;
import com.icap.truequote.crosstrade.service.CacheService;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.mock;

public class InstrumentUpdateCacheHandlerTest {
    private static final Logger LOG = LoggerFactory.getLogger(InstrumentUpdateCacheHandlerTest.class);
    @Mock
    CacheService cacheService;
    @Mock
    InstrumentUpdateCacheHandler instrumentUpdateCacheHandler;
    @Mock
    CrosstradeBond crosstradeBond;

    @Before
    public void setUp() throws Exception {
        cacheService = mock(CacheService.class);
        instrumentUpdateCacheHandler = new InstrumentUpdateCacheHandler(cacheService);
        crosstradeBond = mock(CrosstradeBond.class);
    }

    @Test
    public void onMsg() {
        assertNotNull(instrumentUpdateCacheHandler);
        LOG.info(instrumentUpdateCacheHandler.toString());
        instrumentUpdateCacheHandler.OnMsg(crosstradeBond);
    }

    @After
    public void tearDown() throws Exception {
        instrumentUpdateCacheHandler = null;
        assertNull(instrumentUpdateCacheHandler);

    }
}
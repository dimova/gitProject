package com.icap.truequote.crosstrade.execution.gtn;


import com.icap.envoy.crosstrade.api.Trade;
import com.icap.envoy.crosstrade.api.TradeSide;
import com.icap.truequote.crosstrade.service.CacheService;
import com.icap.truequote.crosstrade.api.Trader;
import org.hamcrest.Matchers;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.time.Clock;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import static com.icap.envoy.crosstrade.api.TradeSide.BUY;
import static com.icap.envoy.crosstrade.api.TradeSide.SELL;
import static java.lang.String.format;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

/* TODO: make these tests more maintainable, lots of duplication */

@RunWith(MockitoJUnitRunner.class)
public class GTNServiceTest {

    private static Logger log = LoggerFactory.getLogger(GTNServiceTest.class);

    private static String TEMP_DIR = System.getProperty("java.io.tmpdir");
    private static final String MARKET_ID = "76";

    @Mock CacheService cacheService;

    private Random rand = new Random();
    private Clock clock = Clock.systemUTC();

    @Test
    public void simpleFileTest() throws IOException, ParseException {
        String orderId = randomOrderId();
        String traderId = UUID.randomUUID().toString();
        TemporalAccessor executionTime = DateTimeFormatter.ISO_DATE_TIME.parse("2015-11-17T17:32:02Z");

        List<Trade> trades = new ArrayList<>();
        trades.add(newTrade(orderId, "555003", traderId, "XS0000000012", 200, BigDecimal.valueOf(106.316), BUY, ZonedDateTime.from(executionTime), "t+2", null, null));
        trades.add(newTrade(orderId, "555003", traderId, "XS0000000012", 200, BigDecimal.valueOf(106.316), SELL, ZonedDateTime.from(executionTime), "t+2", "GBP", new BigDecimal("1.374")));

        GTNService service = new GTNService(new GTNTradeAppender(cacheService, MARKET_ID), null, clock);
        when(cacheService.findTraderByTraderUID(traderId)).thenReturn(newTrader(80002));
        service.execute(trades);

        String filename = format("%s%senvoy_test_%s.csv", TEMP_DIR, File.separator, UUID.randomUUID());
        service.writeToFile(filename, ZonedDateTime.from(executionTime), trades);
        log.info(format("file written: %s", filename));

        BufferedReader reader = new BufferedReader(new FileReader(filename));
        assertThat(reader.readLine(), equalTo("Index,MarketId,Isin,AmountUnit,Amount,PriceType,Price,CustomerNumber,Action,Commission Adjusted Price,Transactions,Time,Day To Settle,Settlement Currency,FX Rate"));
        assertThat(reader.readLine(), equalTo(format("%s,76,XS0000000012,0,200,5,106.316,80002,5,106.326,1,173202,2,null,null", orderId)));
        assertThat(reader.readLine(), equalTo(format("%s,76,XS0000000012,0,200,5,106.316,80002,6,106.326,1,173202,2,GBP,1.374", orderId)));
        assertThat(reader.readLine(), Matchers.nullValue());
        reader.close();
    }

    @Test(expected = IllegalArgumentException.class)
    public void couldNotParseSettlementTest() throws IOException {
        String orderId = randomOrderId();
        String traderId = UUID.randomUUID().toString();
        TemporalAccessor executionTime = DateTimeFormatter.ISO_DATE_TIME.parse("2015-11-17T17:32:02Z");

        List<Trade> trades = new ArrayList<>();
        trades.add(newTrade(orderId, "555003", traderId, "XS0000000012", 200, BigDecimal.valueOf(106.316), BUY, ZonedDateTime.from(executionTime), "2", null, null));
        trades.add(newTrade(orderId, "555003", traderId, "XS0000000012", 200, BigDecimal.valueOf(106.316), SELL, ZonedDateTime.from(executionTime), "2", null, null));

        GTNService service = new GTNService(new GTNTradeAppender(cacheService, MARKET_ID), null, clock);
        when(cacheService.findTraderByTraderUID(traderId)).thenReturn(newTrader(80002));
        service.execute(trades);

        String filename = format("%s%senvoy_test_%s.csv", TEMP_DIR, File.separator, UUID.randomUUID());
        service.writeToFile(filename, ZonedDateTime.from(executionTime), trades);
        log.info(format("file written: %s", filename));

        BufferedReader reader = new BufferedReader(new FileReader(filename));
        assertThat(reader.readLine(), equalTo("Index,MarketId,Isin,AmountUnit,Amount,PriceType,Price,CustomerNumber,Action,Commission Adjusted Price,Transactions,Time,Day To Settle,Settlement Currency,FX Rate"));
        assertThat(reader.readLine(), equalTo(format("%s,76,XS0000000012,0,200,5,106.316,80002,5,106.326,1,173202,2,null,null", orderId)));
        assertThat(reader.readLine(), equalTo(format("%s,76,XS0000000012,0,200,5,106.316,80002,6,106.326,1,173202,2,null,null", orderId)));
        assertThat(reader.readLine(), Matchers.nullValue());
        reader.close();
    }

    private String randomOrderId() {
        return format("%s-%s-%s", rand.nextInt(10000), rand.nextInt(10000), rand.nextInt(10000));
    }

    private static Trade newTrade(String orderId, String userId, String traderId, String isin, int size,
                                  BigDecimal price, TradeSide side, ZonedDateTime time, String settlement,
                                  String settlementCurrency, BigDecimal fxRate) {
        Trade trade = new Trade();
        trade.setOrderId(orderId);
        trade.setUserId(userId);
        trade.setTraderId(traderId);
        trade.setIsin(isin);
        trade.setSettlementCurrency(settlementCurrency);
        trade.setFxRate(fxRate);
        trade.setSize(size);
        trade.setPrice(price);
        trade.setSide(side);
        trade.setExecutedAt(time.toLocalDateTime());
        trade.setAdjustedPrice(price.add(new BigDecimal(0.01)));
        trade.setSettlement(settlement);
        return trade;
    }

    private static Trader newTrader(long accountId) {
        Trader trader = new Trader();
        trader.setGtnAccountId(accountId);
        return trader;
    }
}

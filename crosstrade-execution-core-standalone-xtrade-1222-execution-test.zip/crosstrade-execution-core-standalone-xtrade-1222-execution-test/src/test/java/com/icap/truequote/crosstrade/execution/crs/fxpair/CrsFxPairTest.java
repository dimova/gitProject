package com.icap.truequote.crosstrade.execution.crs.fxpair;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

public class CrsFxPairTest {
    private static final Logger LOG = LoggerFactory.getLogger(CrsFxPairTest.class);
    CrsFxPair crsFxPair;

    @Before
    public void setUp() throws Exception {
        String fromCurrencyCode = "BGN";
        String toCurrencyCode = "EUR";
        BigDecimal crossRate = BigDecimal.valueOf(0.51);
        crsFxPair = new CrsFxPair(fromCurrencyCode, toCurrencyCode, crossRate);
    }

    @After
    public void tearDown() throws Exception {
        crsFxPair = null;
        assertNull(crsFxPair);
    }

    @Test
    public void getFromCurrencyCode() {
        LOG.info(crsFxPair.getFromCurrencyCode());
        assertNotNull(crsFxPair.getFromCurrencyCode());

    }

    @Test
    public void getToCurrencyCode() {
        LOG.info(crsFxPair.getToCurrencyCode());
        assertNotNull(crsFxPair.getToCurrencyCode());

    }

    @Test
    public void getCrossRate() {
        LOG.info(crsFxPair.getCrossRate().toString());
        assertNotNull(crsFxPair.getCrossRate());
    }
}
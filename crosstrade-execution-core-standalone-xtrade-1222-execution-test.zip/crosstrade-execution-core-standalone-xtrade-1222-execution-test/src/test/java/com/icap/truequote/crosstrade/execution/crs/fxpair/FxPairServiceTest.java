package com.icap.truequote.crosstrade.execution.crs.fxpair;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.util.List;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by n_stojanov on 12/02/2018.
 */
@RunWith(MockitoJUnitRunner.class)
public class FxPairServiceTest {

    public static final String REST_URL = "http://exchange-rates.com";

    @Test
    public void testExchangeRate() {
        RestTemplate restTemplate = mock(RestTemplate.class);
        CrsFxPairList testCrsPairs = createTestCrsPairs();
        when(restTemplate.getForObject(REST_URL, CrsFxPairList.class)).thenReturn(testCrsPairs);
        FxPairService fxPairService = new FxPairService(restTemplate, REST_URL);

        Assert.assertEquals(new BigDecimal(1.38), fxPairService.getExchangeRate("GBP"));
        Assert.assertEquals(new BigDecimal(0.78), fxPairService.getExchangeRate("AUD"));
        Assert.assertNull(fxPairService.getExchangeRate("CHF"));
    }

    @Test
    public void testNoConnectionToExchangeService() {
        RestTemplate restTemplate = mock(RestTemplate.class);
        when(restTemplate.getForObject(REST_URL, CrsFxPairList.class)).thenReturn(null);
        FxPairService fxPairService = new FxPairService(restTemplate, REST_URL);

        Assert.assertNull(fxPairService.getExchangeRate("GBP"));
    }

    private CrsFxPairList createTestCrsPairs() {
        CrsFxPairList crsFxPairList = new CrsFxPairList();
        List<CrsFxPair> crossRates = crsFxPairList.getCrossRates();
        crossRates.add(new CrsFxPair("GBP", "USD", new BigDecimal(1.38)));
        crossRates.add(new CrsFxPair("EUR", "USD", new BigDecimal(1.22)));
        crossRates.add(new CrsFxPair("AUD", "USD", new BigDecimal(0.78)));
        crossRates.add(new CrsFxPair("CAD", "USD", new BigDecimal(0.79)));
        return crsFxPairList;
    }

}

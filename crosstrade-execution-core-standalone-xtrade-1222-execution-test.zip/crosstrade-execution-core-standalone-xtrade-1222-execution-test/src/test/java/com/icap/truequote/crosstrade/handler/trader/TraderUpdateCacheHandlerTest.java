package com.icap.truequote.crosstrade.handler.trader;

import com.icap.altex.MsgLib.MsgBase;
import com.icap.truequote.crosstrade.service.CacheService;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static junit.framework.TestCase.assertNull;
import static org.junit.Assert.assertNotNull;

public class TraderUpdateCacheHandlerTest {
    private static final Logger LOG = LoggerFactory.getLogger(TraderUpdateCacheHandlerTest.class);
    @Mock
    TraderUpdateCacheHandler traderUpdateCacheHandler;
    @Mock
    CacheService cacheService;
    @Mock
    MsgBase msgBase;


    @Test
    public void onMsg() {
        traderUpdateCacheHandler = new TraderUpdateCacheHandler(cacheService);
        LOG.info(traderUpdateCacheHandler.toString());
        assertNotNull(traderUpdateCacheHandler);
        traderUpdateCacheHandler.OnMsg(msgBase);
    }

    @Before
    public void setUp() throws Exception {
        cacheService = Mockito.mock(CacheService.class);
        LOG.info(cacheService.toString());
        assertNotNull(cacheService);
    }

    @After
    public void tearDown() throws Exception{
        traderUpdateCacheHandler = null;
        assertNull(traderUpdateCacheHandler);
    }
}
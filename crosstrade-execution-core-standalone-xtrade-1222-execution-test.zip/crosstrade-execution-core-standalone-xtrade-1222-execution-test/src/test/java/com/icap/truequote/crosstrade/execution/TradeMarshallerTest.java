package com.icap.truequote.crosstrade.execution;

import com.icap.truequote.crosstrade.execution.TradeMarshaller;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

public class TradeMarshallerTest {
    @Test
    public void shouldParseLocalAndOffsetDateTimeTest() {
        Map<String, Object> local = new HashMap<>();
        local.put("addedAt", "2016-03-14T09:15:00.200");
        TradeMarshaller.toTrade(local);

        Map<String, Object> offset = new HashMap<>();
        offset.put("addedAt", "2016-03-14T09:15:00.200Z");
        TradeMarshaller.toTrade(offset);
    }
}

package com.icap.truequote.crosstrade.execution.crs.fxpair;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static org.junit.Assert.*;

public class FxPairIdTest {
    private static final Logger LOG = LoggerFactory.getLogger(FxPairIdTest.class);
    FxPairId fxPairId;
    String baseCurrency;
    String targetCurrency;

    @Before
    public void setUp() throws Exception {
        baseCurrency = "BGN";
        targetCurrency = "EUR";
        fxPairId = new FxPairId(baseCurrency, targetCurrency);
    }

    @After
    public void tearDown() throws Exception {
        LOG.info(fxPairId.toString());
        assertEquals(fxPairId,new FxPairId("BGN", "EUR"));
        fxPairId = null;
        assertNull(fxPairId);
    }

    @Test
    public void getBaseCcy() {
        baseCurrency = fxPairId.getBaseCcy();
        LOG.info(baseCurrency);
        assertEquals("BGN", baseCurrency.toUpperCase());

    }

    @Test
    public void getTargetCcy() {
        targetCurrency = fxPairId.getTargetCcy();
        LOG.info(targetCurrency);
        assertEquals("EUR", targetCurrency.toUpperCase());

    }


}
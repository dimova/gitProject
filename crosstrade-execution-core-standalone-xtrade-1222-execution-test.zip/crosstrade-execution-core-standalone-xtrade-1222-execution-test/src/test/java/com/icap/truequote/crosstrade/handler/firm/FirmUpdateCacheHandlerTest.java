package com.icap.truequote.crosstrade.handler.firm;

import com.icap.altex.MsgLib.MsgBase;
import com.icap.truequote.crosstrade.service.CacheService;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static org.junit.Assert.*;

public class FirmUpdateCacheHandlerTest {
    private static final Logger LOG = LoggerFactory.getLogger(FirmUpdateCacheHandlerTest.class);
    @Mock
    CacheService cacheService;
    @Mock
    MsgBase msgBase;
    @Mock
    FirmUpdateCacheHandler firmUpdateCacheHandler;

    @Before
    public void setUp() throws Exception {
        cacheService = Mockito.mock(CacheService.class);
        firmUpdateCacheHandler = new FirmUpdateCacheHandler(cacheService);
    }

    @Test
    public void onMsg() {
        assertNotNull(firmUpdateCacheHandler);
        LOG.info(firmUpdateCacheHandler.toString());
        firmUpdateCacheHandler.OnMsg(msgBase);

    }

    @After
    public void tearDown() throws Exception {
        firmUpdateCacheHandler = null;
        assertNull(firmUpdateCacheHandler);

    }
}
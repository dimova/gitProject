package com.icap.truequote.crosstrade.execution.crs;

import com.icap.truequote.crosstrade.execution.PropertiesContext;
import com.icap.truequote.crosstrade.execution.TestContext;
import junit.framework.TestCase;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.UUID;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { PropertiesContext.class,  TestContext.class, CRSContext.class })
public class CRSServiceIT extends TestCase {

    private static final Logger LOG = LoggerFactory.getLogger(CRSServiceIT.class);

    @Autowired
    private CRSService crs;

    @Test
    public void fetchLimitTest() throws Exception {
        FirmLimit limit = crs.fetchLimit("THREAD14", UUID.randomUUID().toString());
        if (limit != null) {
            LOG.info(String.format("GROUP: %s, LIMIT: %,d, REMAINDER: %,d", limit.groupName, limit.limit, limit.remainder));
        }
    }

    @Test
    public void sendCRSLimitRequest() throws InterruptedException {
        CRSService.CRSChannel channel = crs.sendRequest("THREAD14", UUID.randomUUID().toString());
        Assert.assertNotNull(channel);
    }
}

package com.icap.truequote.crosstrade.execution.crs;

import com.icap.altex.MsgLib.MessageListener;
import com.icap.altex.MsgLib.MsgBase;
import com.icap.altex.MsgLib.MsgLib;
import com.icap.altex.MsgLib.MsgLibTCP;
import com.icap.altex.MsgLib.enums.MsgType;
import com.icap.altex.MsgLib.messages.CRSLimitRequest;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.function.Consumer;

import static java.lang.String.format;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;

public class CRSServiceTest {

    private final Logger LOG = LoggerFactory.getLogger(CRSServiceTest.class);

    private static final String SYSTEM_NAME = "ENVOY";

    /* Arbitrary connection properties */
    private static final String HOST = "";
    private static final int PORT = 0;
    private static final String USERNAME = "";
    private static final String PASSWORD = "";

    private Random rand = new Random();

    private ExecutorService exec = Executors.newCachedThreadPool();

    @Test
    public void receivedCRSLimit() throws Exception {
        final String reqId = format("REQ_%s", randomString());
        final String groupCode = format("GRPCODE_%s", randomString());

        MsgBase msg = MsgBuilder.newMsg(MsgType.CRSLimit)
                .systemName(SYSTEM_NAME)
                .requestId(reqId)
                .groupCode(groupCode)
                .plusSystemLimit(1000, 100)
                .build();

        MsgLib msgLib = createStubbedMsgLib(msg);

        CRSService crs = new CRSService(SYSTEM_NAME,
                new StubbedMsgLibFactory(msgLib, HOST, PORT , USERNAME, PASSWORD), 120, 5);
        FirmLimit limit = crs.fetchLimit(groupCode, reqId);

        assertThat(limit.groupName, equalTo(groupCode));
        assertThat(limit.remainder, equalTo(100L));
    }

    @Test(expected = CRSException.class)
    public void noResponseTest() {
        final String reqId = format("REQ_%s", randomString());
        final String groupCode = format("GRPCODE_%s", randomString());

        MsgLib msgLib = new StubbedMsgLib(i -> {
            /* do nothing */
        });
        CRSService crs = new CRSService(SYSTEM_NAME,
                new StubbedMsgLibFactory(msgLib, HOST, PORT , USERNAME, PASSWORD), 120, 5);
        crs.setMaxRequestAttempts(2);
        crs.fetchLimit(groupCode, reqId);
    }

    @Test
    public void multipleAttemptsTest() {
        for (int i = 0; i < 20; i++) {
            exec.execute(() -> {
                int latency = randomInt(10);
                LOG.info(format("Run test with some latency: %s ms", latency));
                receiveLimitWithLatency(latency);
            });
        }
    }

    private void receiveLimitWithLatency(int milliseconds) {
        final String reqId = format("REQ_%s", randomString());
        final String groupCode = format("GRPCODE_%s", randomString());

        MsgBase msg = MsgBuilder.newMsg(MsgType.CRSLimit)
                .systemName(SYSTEM_NAME)
                .requestId(reqId)
                .groupCode(groupCode)
                .plusSystemLimit(1000, 20)
                .build();

        StubbedMsgLib msgLib = createStubbedMsgLib(msg);

        CRSService crs = new CRSService(SYSTEM_NAME,
                new StubbedMsgLibFactory(msgLib, HOST, PORT , USERNAME, PASSWORD), 120, 5);
        msgLib.Stop();
        exec.execute(() -> {
            try {
                Thread.sleep(milliseconds);
            } catch (InterruptedException e) {
                LOG.error(e.getMessage(), e);
            }

            msgLib.connect();
        });
        FirmLimit limit = crs.fetchLimit(groupCode, reqId);

        assertThat(limit.groupName, equalTo(groupCode));
        assertThat(limit.remainder, equalTo(20L));
    }

    private String randomString() {
        byte[] b = new byte[4];
        rand.nextBytes(b);
        return b.toString();
    }

    /* returns number between 1 and max */
    private int randomInt(int max) {
        return rand.nextInt(max);
    }

    /* A stubbed MsgLib object that exposes the internal topics and message queue to a consumer.
     * General hoop jumping in order to make MsgLib more test friendly
     */
    class StubbedMsgLib extends MsgLibTCP {
        final Consumer<MsgLibInternals> consumer;
        boolean isConnected = false;

        StubbedMsgLib(Consumer<MsgLibInternals> consumer) {
            super(HOST, PORT, USERNAME, PASSWORD);
            this.consumer = consumer;
        }

        @Override
        public void connect() {
            isConnected = true;
            notifyConnected();
        }

        @Override
        public void Stop() {
            isConnected = false;
            notifyDisconnected(new RuntimeException("Stubbed MsgLib was stopped."));
        }

        @Override
        public boolean isConnected() {
            return isConnected;
        }

        @Override
        public void send(ByteBuffer b, short msgType, String topic) {
            if (!isConnected) {
                LOG.error("Failed to send, not connected");
                return;
            }

            LOG.info("Request: {}", new String(b.array(), Charset.forName("UTF-8")));
            try {
                b.position(0);
                MsgBase msg = MsgBase.DecodeMessage(b);

                /* invoke the response if the request was for a CRS limit */
                if (msg instanceof CRSLimitRequest) {
                    sendResponse();
                }

            } catch (Exception e) {
                LOG.error(e.getMessage(), e);
            }
        }

        private void sendResponse() {
            LOG.info("Invoking response sequence...");
            consumer.accept(new MsgLibInternals(this.topicsWildcard, this.incomingMessages));
        }
    }

    private StubbedMsgLib createStubbedMsgLib(MsgBase msg) {
        StubbedMsgLib msgLib = new StubbedMsgLib(internals -> {
            MessageListener msgListener = internals.topicsWildcard.get(msg.msgType).get("*");
            LinkedList<MessageListener> callbacks = new LinkedList<>();
            callbacks.add(msgListener);
            msg.callbacks = callbacks;

            try {
                internals.incomingMessages.put(msg);
            } catch (InterruptedException e) {
                LOG.error(e.getMessage(), e);
            }
        });
        return msgLib;
    }

    /* Encapsulates various MsgLib internals */
    class MsgLibInternals {
        final EnumMap<MsgType, HashMap<String, MessageListener>> topicsWildcard;
        final LinkedBlockingQueue<MsgBase> incomingMessages;

        public MsgLibInternals(EnumMap<MsgType, HashMap<String, MessageListener>> topicsWildcard, LinkedBlockingQueue<MsgBase> msgQueue) {
            this.topicsWildcard = topicsWildcard;
            this.incomingMessages = msgQueue;
        }
    }
}

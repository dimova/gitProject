package com.icap.truequote.crosstrade.execution;

import com.icap.envoy.crosstrade.referencedata.api.Environment;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

public class PropertiesContextTest {

    PropertiesContext propertiesContext;

    private static final Logger LOG = LoggerFactory.getLogger(PropertiesContextTest.class);
    @Before
    public void setUp() throws Exception {
        propertiesContext = new PropertiesContext();

    }

    @After
    public void tearDown() throws Exception {
        propertiesContext = null;
        assertNull(propertiesContext);
    }

    @Test
    public void getEnvironment() {
        final Environment environment = propertiesContext.getEnvironment();
        LOG.info(environment.toString());
        assertNotNull(environment);

    }
}
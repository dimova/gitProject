package com.icap.truequote.crosstrade.execution.crs;

import com.icap.altex.MsgLib.MsgBase;
import com.icap.altex.MsgLib.enums.MsgType;
import com.icap.altex.MsgLib.messages.CRSLimit;
import com.icap.altex.MsgLib.messages.CRSSystemLimit;

import java.util.ArrayList;

public final class MsgBuilder {
    private String systemName;
    private String requestId;
    private String groupCode;
    private MsgType msgType;

    /* specific to limits */
    private ArrayList<CRSSystemLimit> systemLimits;

    public MsgBuilder(MsgType msgType) {
        this.msgType = msgType;
    }

    public static MsgBuilder newMsg(MsgType msgType) {
        MsgBuilder builder = new MsgBuilder(msgType);
        return builder;
    }

    public MsgBuilder systemName(String systemName) {
        this.systemName = systemName;
        return this;
    }

    public MsgBuilder requestId(String requestId) {
        this.requestId = requestId;
        return this;
    }

    public MsgBuilder groupCode(String groupCode) {
        this.groupCode = groupCode;
        return this;
    }

    public MsgBuilder plusSystemLimit(long limit, long remainder) {
        if (systemLimits == null)
            systemLimits = new ArrayList<>();

        if (systemName == null)
            throw new IllegalStateException("SystemName must be set.");

        CRSSystemLimit sysLimit = new CRSSystemLimit();
        sysLimit.setSystemName(systemName);
        sysLimit.setInitialMarginLimit(limit);
        sysLimit.setInitialMarginRemainder(remainder);

        systemLimits.add(sysLimit);
        return this;
    }

    public MsgBase build() {
        switch (msgType) {
            case CRSLimit:
                CRSLimit crsLimit = new CRSLimit();
                crsLimit.setRequestId(requestId);
                crsLimit.setGroupCode(groupCode);
                crsLimit.setSystemLimitList(systemLimits);
                return crsLimit;
            default:
                throw new IllegalStateException("Unknown MsgType.");
        }
    }
}

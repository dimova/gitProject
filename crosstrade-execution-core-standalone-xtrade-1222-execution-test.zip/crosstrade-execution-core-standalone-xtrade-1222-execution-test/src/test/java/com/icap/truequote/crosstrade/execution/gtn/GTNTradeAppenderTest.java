package com.icap.truequote.crosstrade.execution.gtn;

import com.icap.envoy.crosstrade.api.Trade;
import com.icap.envoy.crosstrade.api.TradeSide;
import com.icap.truequote.crosstrade.execution.gtn.GTNTradeAppender;
import com.icap.truequote.crosstrade.service.CacheService;
import com.icap.truequote.crosstrade.api.Trader;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.IOException;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.text.ParseException;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import java.util.Arrays;

import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class GTNTradeAppenderTest {

    @Mock
    CacheService cacheService;

    String marketId = "76";
    String EXPECTED_HEADER = "Index,MarketId,Isin,AmountUnit,Amount,PriceType,Price,CustomerNumber,Action,Commission Adjusted Price,Transactions,Time,Day To Settle,Settlement Currency,FX Rate";

    @Test
    public void testStringFormat() throws ParseException, IOException {
        GTNTradeAppender marshaller = new GTNTradeAppender(cacheService, marketId);
        TemporalAccessor execTime = DateTimeFormatter.ISO_DATE_TIME.parse("2015-11-17T18:51:20+00:00");

        Trade buy = newTrade("order-1", "XS00000732", 100000, 98.12, TradeSide.BUY, 98.13, "t+2", "trader-1", null, null);
        Trade sell = newTrade("order-1", "XS00000732", 100000, 98.12, TradeSide.SELL, 98.11, "t+2", "trader-1","GBP", new BigDecimal("1.374"));
        Trader trader = newTrader(60021);
        when(cacheService.findTraderByTraderUID("trader-1")).thenReturn(trader);

        StringWriter writer = new StringWriter();
        marshaller.append(writer, Arrays.asList(buy, sell), ZonedDateTime.from(execTime));
        writer.close();

        String[] lines = writer.toString().split("\n");
        assertThat(lines.length, equalTo(3));
        assertThat(lines[0], equalTo(EXPECTED_HEADER));
        assertThat(lines[1], equalTo("order-1,76,XS00000732,0,100000,5,98.12,60021,5,98.13,1,185120,2,null,null"));
        assertThat(lines[2], equalTo("order-1,76,XS00000732,0,100000,5,98.12,60021,6,98.11,1,185120,2,GBP,1.374"));
    }

    private static Trade newTrade(String orderId, String isin, int size, double price, TradeSide side,
                                  double adjustedPrice, String settlement, String traderId,
                                  String settlementCurrency, BigDecimal fxRate) {
        Trade trade = new Trade();
        trade.setOrderId(orderId);
        trade.setIsin(isin);
        trade.setSettlementCurrency(settlementCurrency);
        trade.setFxRate(fxRate);
        trade.setSize(size);
        trade.setPrice(new BigDecimal(price));
        trade.setSide(side);
        trade.setAdjustedPrice(new BigDecimal(adjustedPrice));
        trade.setSettlement(settlement);
        trade.setTraderId(traderId);
        return trade;
    }

    private static Trader newTrader(long customerNumber) {
        Trader trader = new Trader();
        trader.setGtnAccountId(customerNumber);
        return trader;
    }
}

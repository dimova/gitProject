package com.icap.truequote.crosstrade.execution;

import com.icap.envoy.crosstrade.api.Position;
import com.icap.envoy.crosstrade.api.Trade;
import com.icap.envoy.crosstrade.api.TradeSide;
import com.icap.envoy.crosstrade.api.TradeStatus;
import com.icap.envoy.crosstrade.auditing.EnvoyAuditLog;
import com.icap.envoy.crosstrade.dao.PositionDao;
import com.icap.envoy.crosstrade.dao.TradeDao;
import com.icap.fusion.altex.MsgLibConnection;
import com.icap.fusion.sso.sp.api.session.SpSession;
import com.icap.truequote.crosstrade.api.Firm;
import com.icap.truequote.crosstrade.api.Instrument;
import com.icap.truequote.crosstrade.api.Trader;
import com.icap.truequote.crosstrade.execution.crs.CRSService;
import com.icap.truequote.crosstrade.execution.crs.FirmLimit;
import com.icap.truequote.crosstrade.execution.crs.fxpair.FxPairService;
import com.icap.truequote.crosstrade.execution.gtn.GTNService;
import com.icap.truequote.crosstrade.service.CacheService;
import com.icap.truequote.crosstrade.util.CommonUtils;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.ZonedDateTime;
import java.util.*;
import java.util.function.Function;

import static com.google.common.collect.Lists.newArrayList;
import static com.icap.envoy.crosstrade.api.TradeSide.BUY;
import static com.icap.envoy.crosstrade.api.TradeSide.SELL;
import static com.icap.envoy.crosstrade.api.TradeStatus.EXECUTION_REQUESTED;
import static com.icap.envoy.crosstrade.api.TradeStatus.INVALID;
import static java.lang.String.format;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class TradeExecutionHandlerTest {

    private static final Clock clock = Clock.systemUTC();

    private static final String SYSTEM_NAME = "ENVOY";
    private static final String GROUP_CODE = "TESTLTD";
    private static final String ISIN = "TX001";
    private static final String TRADER_ID = "trader_guy";
    private static final String USER_ID = "user_guy";

    private static final double DELTA = Math.pow(0.1, TradeExecutionHandler.BROKER_RATE_PRECISION + 1);

    @Mock
    CRSService crs;
    @Mock
    GTNService gtn;
    @Mock
    TradeDao tradeDao;
    @Mock
    PositionDao positionDao;
    @Mock
    CacheService cacheService;
    @Mock
    FxPairService fxPairService;
    @Mock
    EnvoyAuditLog envoyAuditLog;
    @Mock
    MsgLibConnection msgLibConnection;

    private String groupNames = "GroupData";

    private Random rand = new Random();

    /* TODO: clean these tests up in general; they need to be easily maintainable */
    @Ignore("review it")
    @Test
    public void testModify() throws InterruptedException {

        int timeLimit = 1000;
        int batchTimeout = 1000;

        TradeExecutionHandler handler = new TradeExecutionHandler(crs, gtn, tradeDao, positionDao, cacheService, fxPairService,
                batchTimeout / 1000, groupNames, msgLibConnection, envoyAuditLog);
        String firmId = UUID.randomUUID().toString();
        String orderId = randomOrderId();
        String batchId = UUID.randomUUID().toString();

        Firm firm = newFirm(GROUP_CODE);
        when(cacheService.findFirmByFirmUID(firmId.toString())).thenReturn(firm);

        Trader trader = newTrader(1112, 0.02);
        when(cacheService.findTraderByTraderUID(TRADER_ID)).thenReturn(trader);

        Position position = newPosition(USER_ID, orderId);
        HashMap<String, Position> positionsByOrder = new HashMap<>();
        positionsByOrder.put(orderId, position);
        when(positionDao.findPositionByOrderIds(USER_ID, newArrayList(orderId))).thenReturn(positionsByOrder);

        FirmLimit limit = newLimit(GROUP_CODE, 1000000, 1000000);
        when(crs.fetchLimit(GROUP_CODE, batchId.toString())).thenReturn(limit);

        when(gtn.execute(any(List.class))).thenReturn(ZonedDateTime.now(clock));

        Trade buy = newTrade(USER_ID, TRADER_ID, firmId, ISIN, orderId, "t+2", BUY, EXECUTION_REQUESTED, 102.39, 1000, batchId, 2);
        Trade sell = newTrade(USER_ID, TRADER_ID, firmId, ISIN, orderId, "t+2", SELL, EXECUTION_REQUESTED, 102.39, 1000, batchId, 2);

        handler.executeTrades(trader, newArrayList(sell));
        handler.executeTrades(trader, newArrayList(buy));
        Thread.sleep(timeLimit);

        ArgumentCaptor<List> trades = ArgumentCaptor.forClass(List.class);
        verify(tradeDao, times(1)).save(trades.capture());
        List<Trade> updates = trades.getValue();
        assertThat(updates.size(), equalTo(2));
        updates.forEach(trade -> {
            assertThat(trade.getUserId(), equalTo(USER_ID));
            assertThat(trade.getOrderId(), equalTo(orderId));
            assertThat(trade.getExecutionBatchId(), equalTo(batchId));
            assertThat(trade.getExecutionBatchSize(), equalTo(2));
            assertThat(trade.getStatus(), equalTo(TradeStatus.EXECUTED));

            if (BUY == trade.getSide())
                assertThat(trade.getAdjustedPrice().doubleValue(), equalTo(102.4));

            if (SELL == trade.getSide())
                assertThat(trade.getAdjustedPrice().doubleValue(), equalTo(102.38));
        });

        ArgumentCaptor<List> positions = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<String> userId = ArgumentCaptor.forClass(String.class);
        verify(positionDao, times(1)).delete(userId.capture(), positions.capture());
        assertThat(userId.getValue(), equalTo(USER_ID));

        assertThat(positions.getValue().size(), equalTo(1));

        ArgumentCaptor<List> executed = ArgumentCaptor.forClass(List.class);
        verify(gtn, times(1)).execute(executed.capture());
        assertThat(executed.getValue().size(), equalTo(2));
    }

    @Ignore("review it")
    @Test
    public void testExecutionFailed() throws InterruptedException {
        int timeLimit = 1000;
        int batchTimeout = 1000;

        TradeExecutionHandler handler = new TradeExecutionHandler(crs, gtn, tradeDao, positionDao, cacheService, fxPairService,
                batchTimeout / 1000, groupNames, msgLibConnection, envoyAuditLog);
        String firmId = UUID.randomUUID().toString();
        String orderId = randomOrderId();
        String batchId = UUID.randomUUID().toString();

        Firm firm = newFirm(GROUP_CODE);
        when(cacheService.findFirmByFirmUID(firmId.toString())).thenReturn(firm);

        Trader trader = newTrader(1112, 0.02);
        when(cacheService.findTraderByTraderUID(TRADER_ID)).thenReturn(trader);

        Position position = newPosition(USER_ID, orderId);
        when(positionDao.findPositionByOrderId(USER_ID, orderId)).thenReturn(position);

        FirmLimit limit = newLimit(GROUP_CODE, 1000000, 1000000);
        when(crs.fetchLimit(GROUP_CODE, batchId.toString())).thenReturn(limit);

        /* simulate a downstream failure */
        when(gtn.execute(any(List.class))).thenThrow(new TradeExecutionException("downstream failure"));

        Trade buy = newTrade(USER_ID, TRADER_ID, firmId, ISIN, orderId, "t+2", BUY, EXECUTION_REQUESTED, 102.39, 1000, batchId, 2);
        Trade sell = newTrade(USER_ID, TRADER_ID, firmId, ISIN, orderId, "t+2", SELL, EXECUTION_REQUESTED, 102.39, 1000, batchId, 2);

        handler.executeTrades(trader, newArrayList(sell, buy));
        Thread.sleep(timeLimit);

        ArgumentCaptor<List> trades = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<SpSession> session = ArgumentCaptor.forClass(SpSession.class);
        verify(tradeDao, times(1)).save(trades.capture());
        session.getAllValues().stream().forEach(s -> assertThat(s.getUser().getId(), equalTo(USER_ID)));
        List<Trade> updated = trades.getValue();
        assertThat(updated.size(), equalTo(2));
        updated.stream().forEach(t -> {
            assertThat(t.getOrderId(), equalTo(orderId));
            assertThat(t.getExecutionBatchId(), equalTo(batchId));
            assertThat(t.getExecutionBatchSize(), equalTo(2));

            assertThat(t.getStatus(), equalTo(TradeStatus.PENDING));
            assertThat(t.getAdjustedPrice(), nullValue());
        });
    }

    @Test
    public void testInsert() throws InterruptedException {
        int timeLimit = 1000;
        int batchTimeout = 1000;

        Trade trade = newTrade("user_2", "trader_2", UUID.randomUUID().toString(), "isin_2", randomOrderId(), "t+1", SELL, INVALID, 109.84, 1000, UUID.randomUUID().toString(), 2);

        TradeExecutionHandler handler = new TradeExecutionHandler(crs, gtn, tradeDao, positionDao, cacheService, fxPairService,
                batchTimeout / 1000, groupNames, msgLibConnection, envoyAuditLog);
        handler.executeTrades(null, newArrayList(trade));
        Thread.sleep(timeLimit);

        verifyZeroInteractions(crs, gtn, tradeDao, positionDao);
    }

    @Ignore("review it")
    @Test
    public void testBatchTimeout() throws InterruptedException {
        int timeLimit = 2000;
        int batchTimeout = 1000;

        TradeExecutionHandler handler = new TradeExecutionHandler(crs, gtn, tradeDao, positionDao, cacheService, fxPairService,
                batchTimeout / 1000, groupNames, msgLibConnection, envoyAuditLog);
        String firmId = UUID.randomUUID().toString();
        String orderId = randomOrderId();
        String batchId = UUID.randomUUID().toString();

        Firm firm = newFirm(GROUP_CODE);
        when(cacheService.findFirmByFirmUID(firmId.toString())).thenReturn(firm);

        Trader trader = newTrader(1112, 0.02);
        when(cacheService.findTraderByTraderUID(TRADER_ID)).thenReturn(trader);

        Position position = newPosition(USER_ID, orderId);
        when(positionDao.findPositionByOrderId(USER_ID, orderId)).thenReturn(position);

        FirmLimit limit = newLimit(GROUP_CODE, 1000000, 1000000);
        when(crs.fetchLimit(GROUP_CODE, batchId.toString())).thenReturn(limit);

        Trade buy = newTrade(USER_ID, TRADER_ID, firmId, ISIN, orderId, "t+2", BUY, EXECUTION_REQUESTED, 102.39, 1000, batchId, 2);

        /* notice only the buy is received in this test */
        handler.executeTrades(trader, newArrayList(buy));
        Thread.sleep(timeLimit);

        verifyZeroInteractions(gtn);

        ArgumentCaptor<List> trades = ArgumentCaptor.forClass(List.class);
        verify(tradeDao, times(1)).save(trades.capture());

        /* expect: since only 1 trade was received, the batch times out, and the received trade is updated to pending */
        List<Trade> capturedTrades = trades.getValue();
        assertThat(capturedTrades.size(), equalTo(1));
        Trade trade = capturedTrades.get(0);
        assertThat(trade.getUserId(), equalTo(USER_ID));
        assertThat(trade.getOrderId(), equalTo(orderId));
        assertThat(trade.getExecutionBatchId(), equalTo(batchId));
        assertThat(trade.getExecutionBatchSize(), equalTo(2));

        assertThat(trade.getStatus(), equalTo(TradeStatus.PENDING));
        assertThat(trade.getAdjustedPrice(), nullValue());
    }

    private String randomOrderId() {
        return format("%s-%s-%s", rand.nextInt(10000), rand.nextInt(10000), rand.nextInt(10000));
    }

    private static Trade newTrade(String userId, String traderId, String firmId, String isin, String orderId,
                                  String settlement, TradeSide side, TradeStatus status, double price, int size,
                                  String batchId, int batchSize) {
        Trade trade = new Trade();
        trade.setId(UUID.randomUUID().toString());
        trade.setUserId(userId);
        trade.setTraderId(traderId);
        trade.setFirmId(firmId);
        trade.setIsin(isin);
        trade.setOrderId(orderId);
        trade.setSettlement(settlement);
        trade.setSide(side);
        trade.setStatus(status);
        trade.setPrice(new BigDecimal(price));
        trade.setSize(size);
        trade.setExecutionBatchId(batchId);
        trade.setExecutionBatchSize(batchSize);
        return trade;
    }

    private static Firm newFirm(String groupCode) {
        Firm firm = new Firm();
        firm.setGroupCode(groupCode);
        return firm;
    }

    private static Trader newTrader(long gtnAccountId, double rate) {
        Trader trader = new Trader();
        trader.setGtnAccountId(gtnAccountId);
        trader.setBrokerRate(new BigDecimal(rate));
        return trader;
    }

    private static FirmLimit newLimit(String groupCode, long limit, long remainder) {
        return new FirmLimit(SYSTEM_NAME, groupCode, limit, remainder);
    }

    private static Map<String, Object> newMessage(String action, Trade trade) {
        HashMap<String, Object> obj = new HashMap<>();
        obj.put("id", trade.getId().toString());
        obj.put("userId", trade.getUserId());
        obj.put("traderId", trade.getTraderId());
        obj.put("firmId", trade.getFirmId().toString());
        obj.put("isin", trade.getIsin());
        obj.put("orderId", trade.getOrderId().toString());
        obj.put("settlement", trade.getSettlement());
        obj.put("side", trade.getSide().name());
        obj.put("status", trade.getStatus().name());
        obj.put("price", trade.getPrice().toString());
        obj.put("size", trade.getSize().toString());
        obj.put("executionBatchId", trade.getExecutionBatchId().toString());
        obj.put("executionBatchSize", trade.getExecutionBatchSize().toString());

        HashMap<String, Object> prev = new HashMap<>();
        prev.put("id", trade.getId().toString());
        prev.put("userId", trade.getUserId());
        prev.put("traderId", trade.getTraderId());
        prev.put("firmId", trade.getFirmId().toString());
        prev.put("isin", trade.getIsin());
        prev.put("orderId", trade.getOrderId().toString());
        prev.put("settlement", trade.getSettlement());
        prev.put("side", trade.getSide().name());
        prev.put("status", TradeStatus.PENDING.name());
        prev.put("price", trade.getPrice().toString());
        prev.put("size", trade.getSize().toString());
        prev.put("executionBatchId", trade.getExecutionBatchId().toString());
        prev.put("executionBatchSize", trade.getExecutionBatchSize().toString());

        HashMap<String, Object> message = new HashMap<>();
        message.put("action", action);
        message.put("new", obj);
        message.put("old", prev);
        return message;
    }

    private Position newPosition(String userId, String orderId) {
        Position position = new Position();
        position.setUserId(userId);
        position.setOrderId(orderId);
        return position;
    }

    @Test
    public void testAdjustedPrice() {
        double price = 100, rate = 0.002001;
        BigDecimal brokerRate = new BigDecimal(rate);
        String isin = "ISIN1";
        String currency = "USD";

        Trade sell = new Trade();
        sell.setSide(TradeSide.SELL);
        sell.setPrice(new BigDecimal(price));
        sell.setIsin(isin);

        Trade buy = new Trade();
        buy.setSide(TradeSide.BUY);
        buy.setPrice(new BigDecimal(price));
        buy.setIsin(isin);

        Instrument instrument = new Instrument();
        instrument.setIsin(isin);
        instrument.setCcy(currency);
        when(cacheService.findInstrumentByIsin(isin)).thenReturn(instrument);
        when(fxPairService.getExchangeRate(currency)).thenReturn(BigDecimal.ONE);
        int batchTimeout = 1000;

        TradeExecutionHandler handler = new TradeExecutionHandler(crs, gtn, tradeDao, positionDao, cacheService, fxPairService,
                batchTimeout / 1000, groupNames, msgLibConnection, envoyAuditLog);

        BigDecimal adjustedPrice = handler.adjustedPrice(sell, brokerRate);
        Assert.assertNotEquals(price, adjustedPrice.doubleValue(), DELTA);
        Assert.assertEquals(price - rate / 2, adjustedPrice.doubleValue(), DELTA);

        adjustedPrice = handler.adjustedPrice(buy, brokerRate);
        Assert.assertNotEquals(price, adjustedPrice.doubleValue(), DELTA);
        Assert.assertEquals(price + rate / 2, adjustedPrice.doubleValue(), DELTA);
    }

    @Test
    public void isExecutedFixTrade() {
        Function<Trade, Boolean> isExecuted = TradeExecutionHandler::isExecutedFixTrade;
        Trade trade = new Trade();
        Assert.assertFalse(isExecuted.apply(trade));

        trade.setStatus(TradeStatus.EXECUTED);
        Assert.assertFalse(isExecuted.apply(trade));

        trade.setFixOrderId(CommonUtils.randomUUID());
        Assert.assertTrue(isExecuted.apply(trade));

        trade.setStatus(TradeStatus.INVALID);
        Assert.assertFalse(isExecuted.apply(trade));
    }

    @Test
    public void testFxRateWithoutIsin() {
        //The fx rate should be 1 when the trade has no ISIN
        double price = 100, rate = 0.002001;
        BigDecimal brokerRate = new BigDecimal(rate);
        int batchTimeout = 1000;

        Trade trade = new Trade();
        trade.setSide(TradeSide.SELL);
        trade.setPrice(new BigDecimal(price));
        trade.setIsin(null);

        TradeExecutionHandler handler = new TradeExecutionHandler(crs, gtn, tradeDao, positionDao, cacheService, fxPairService,
                batchTimeout / 1000, groupNames, msgLibConnection, envoyAuditLog);

        BigDecimal adjustedPrice = handler.adjustedPrice(trade, brokerRate);
        Assert.assertNotEquals(price, adjustedPrice.doubleValue(), DELTA);
        Assert.assertEquals(price - rate / 2, adjustedPrice.doubleValue(), DELTA);

        trade.setIsin("");
        adjustedPrice = handler.adjustedPrice(trade, brokerRate);
        Assert.assertNotEquals(price, adjustedPrice.doubleValue(), DELTA);
        Assert.assertEquals(price - rate / 2, adjustedPrice.doubleValue(), DELTA);
    }

    @Test
    public void testFxRateWithoutInstrument() {
        //The fx rate should be 1 when there is no instrument with the trade's isin
        double price = 100, rate = 0.002001;
        BigDecimal brokerRate = new BigDecimal(rate);
        int batchTimeout = 1000;
        String isin = "ISIN1";

        Trade trade = new Trade();
        trade.setSide(TradeSide.SELL);
        trade.setPrice(new BigDecimal(price));
        trade.setIsin(isin);

        TradeExecutionHandler handler = new TradeExecutionHandler(crs, gtn, tradeDao, positionDao, cacheService, fxPairService,
                batchTimeout / 1000, groupNames, msgLibConnection, envoyAuditLog);

        when(cacheService.findInstrumentByIsin(isin)).thenReturn(null);

        BigDecimal adjustedPrice = handler.adjustedPrice(trade, brokerRate);
        Assert.assertNotEquals(price, adjustedPrice.doubleValue(), DELTA);
        Assert.assertEquals(price - rate / 2, adjustedPrice.doubleValue(), DELTA);
    }

    @Test
    public void testFxRateNoCurrency() {
        //The fx rate should be 1 when the trade's currency can't be determined
        double price = 100, rate = 0.002001;
        BigDecimal brokerRate = new BigDecimal(rate);
        int batchTimeout = 1000;
        String isin = "ISIN1";

        Trade trade = new Trade();
        trade.setSide(TradeSide.SELL);
        trade.setPrice(new BigDecimal(price));
        trade.setIsin(isin);

        TradeExecutionHandler handler = new TradeExecutionHandler(crs, gtn, tradeDao, positionDao, cacheService, fxPairService,
                batchTimeout / 1000, groupNames, msgLibConnection, envoyAuditLog);

        Instrument instrument = new Instrument();
        instrument.setIsin(isin);
        instrument.setCcy("");
        when(cacheService.findInstrumentByIsin(isin)).thenReturn(instrument);

        BigDecimal adjustedPrice = handler.adjustedPrice(trade, brokerRate);
        Assert.assertNotEquals(price, adjustedPrice.doubleValue(), DELTA);
        Assert.assertEquals(price - rate / 2, adjustedPrice.doubleValue(), DELTA);
    }

    @Test
    public void testNullExchangeRateFromService() {
        //The fx rate should be 1 when null is returned from the fxPairService
        double price = 100, rate = 0.002001;
        BigDecimal brokerRate = new BigDecimal(rate);
        int batchTimeout = 1000;
        String isin = "ISIN1";
        String tradeCurrency = "GBP";

        Trade trade = new Trade();
        trade.setSide(TradeSide.SELL);
        trade.setPrice(new BigDecimal(price));
        trade.setIsin(isin);

        TradeExecutionHandler handler = new TradeExecutionHandler(crs, gtn, tradeDao, positionDao, cacheService, fxPairService,
                batchTimeout / 1000, groupNames, msgLibConnection, envoyAuditLog);

        Instrument instrument = new Instrument();
        instrument.setIsin(isin);
        instrument.setCcy(tradeCurrency);
        when(cacheService.findInstrumentByIsin(isin)).thenReturn(instrument);
        when(fxPairService.getExchangeRate(tradeCurrency)).thenReturn(null);

        BigDecimal adjustedPrice = handler.adjustedPrice(trade, brokerRate);
        Assert.assertNotEquals(price, adjustedPrice.doubleValue(), DELTA);
        Assert.assertEquals(price - rate / 2, adjustedPrice.doubleValue(), DELTA);
    }

    @Test
    public void testAdjustedPriceWithFxRate() {
        double price = 100, rate = 0.002001;
        BigDecimal brokerRate = new BigDecimal(rate);
        int batchTimeout = 1000;
        String isin = "ISIN1";
        String tradeCurrency = "GBP";
        double exchangeRate = 1.38;

        Trade trade = new Trade();
        trade.setSide(TradeSide.SELL);
        trade.setPrice(new BigDecimal(price));
        trade.setIsin(isin);

        TradeExecutionHandler handler = new TradeExecutionHandler(crs, gtn, tradeDao, positionDao, cacheService, fxPairService,
                batchTimeout / 1000, groupNames, msgLibConnection, envoyAuditLog);

        Instrument instrument = new Instrument();
        instrument.setIsin(isin);
        instrument.setCcy(tradeCurrency);
        when(cacheService.findInstrumentByIsin(isin)).thenReturn(instrument);
        when(fxPairService.getExchangeRate(tradeCurrency)).thenReturn(new BigDecimal(exchangeRate));

        BigDecimal adjustedPrice = handler.adjustedPrice(trade, brokerRate);
        Assert.assertNotEquals(price, adjustedPrice.doubleValue(), DELTA);
        Assert.assertEquals((price - rate / 2) / exchangeRate, adjustedPrice.doubleValue(), DELTA);
    }

    @Test
    public void testFxRateForTradeWithCurrency() {
        double price = 100, rate = 0.002001;
        BigDecimal brokerRate = new BigDecimal(rate);
        int batchTimeout = 1000;
        String tradeCurrency = "GBP";
        double exchangeRate = 1.38;

        Trade trade = new Trade();
        trade.setSide(TradeSide.SELL);
        trade.setPrice(new BigDecimal(price));
        trade.setCcy(tradeCurrency);

        TradeExecutionHandler handler = new TradeExecutionHandler(crs, gtn, tradeDao, positionDao, cacheService, fxPairService,
                batchTimeout / 1000, groupNames, msgLibConnection, envoyAuditLog);

        when(fxPairService.getExchangeRate(tradeCurrency)).thenReturn(new BigDecimal(exchangeRate));

        BigDecimal adjustedPrice = handler.adjustedPrice(trade, brokerRate);
        Assert.assertNotEquals(price, adjustedPrice.doubleValue(), DELTA);
        Assert.assertEquals((price - rate / 2) / exchangeRate, adjustedPrice.doubleValue(), DELTA);
    }

    @Test
    public void testSettlementFxRate() {
        double price = 100, rate = 0.002001;
        BigDecimal brokerRate = new BigDecimal(rate);
        int batchTimeout = 1000;
        double exchangeRate = 1.38;

        Trade trade = new Trade();
        trade.setSide(TradeSide.SELL);
        trade.setPrice(new BigDecimal(price));
        trade.setFxRate(new BigDecimal(exchangeRate));

        TradeExecutionHandler handler = new TradeExecutionHandler(crs, gtn, tradeDao, positionDao, cacheService, fxPairService,
                batchTimeout / 1000, groupNames, msgLibConnection, envoyAuditLog);

        BigDecimal adjustedPrice = handler.adjustedPrice(trade, brokerRate);
        Assert.assertNotEquals(price, adjustedPrice.doubleValue(), DELTA);
        Assert.assertEquals((price - rate / 2) / exchangeRate, adjustedPrice.doubleValue(), DELTA);
    }

}

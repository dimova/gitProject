package com.icap.truequote.crosstrade.execution.crs;

import com.icap.altex.MsgLib.ConnectionListener;
import com.icap.altex.MsgLib.MsgLib;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 */
public class StubbedMsgLibFactory extends CrsMsgLibFactory {

    private final Logger LOGGER = LoggerFactory.getLogger(CRSServiceTest.class);

    private MsgLib msglib;

    public StubbedMsgLibFactory(MsgLib msglib, String host, int port, String username, String password) {
        super(host, port, username, password);
        this.msglib = msglib;
    }

    @Override
    public MsgLib getMsgLib(ConnectionListener listener) {
        msglib.addConnectionListener(listener);
        try {
            msglib.connect();
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return msglib;
    }
}
